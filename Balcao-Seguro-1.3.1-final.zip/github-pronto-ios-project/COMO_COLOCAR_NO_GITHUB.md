# Como colocar o Balcão Seguro no GitHub e gerar APK

## Opção mais fácil: pelo site do GitHub

1. Entre no GitHub e crie um repositório novo.
2. Recomendo marcar como **Private**.
3. Extraia este ZIP no Mac.
4. Abra a pasta `balcao-seguro-github-pronto`.
5. Envie **o conteúdo de dentro da pasta** para o repositório, não o ZIP fechado.
6. Confirme que estes arquivos foram enviados:
   - `package.json`
   - `App.tsx`
   - `src/`
   - `assets/`
   - `.github/workflows/gerar-apk-android.yml`
7. Vá em **Actions**.
8. Abra **Gerar APK Android - Balcao Seguro**.
9. Clique em **Run workflow**.
10. Aguarde terminar.
11. No final da execução, baixe o artefato **Balcao-Seguro-APK-Release**.
12. Dentro do ZIP baixado pelo GitHub estará o APK:

```text
Balcao-Seguro-v1.1.5-github-release.apk
```

## Pelo Terminal do Mac

Troque `SEU_USUARIO` pelo seu usuário do GitHub e crie antes um repositório chamado `balcao-seguro`.

```bash
cd ~/Desktop/balcao-seguro-github-pronto

git init
git branch -M main
git add .
git commit -m "Balcao Seguro v1.1.5 github"
git remote add origin https://github.com/SEU_USUARIO/balcao-seguro.git
git push -u origin main
```

Depois vá em **Actions** no GitHub e rode o workflow.

## Observação sobre instalação no Android

O APK gerado pelo GitHub é para instalar direto no Android físico.

Se o Android reclamar de assinatura ao atualizar uma versão anterior, desinstale o app antigo e instale o novo APK. Isso pode acontecer quando o APK anterior foi assinado por outra chave.

## Se o build release falhar

Rode o workflow alternativo:

```text
Gerar APK Debug - Plano B
```

Ele gera um APK de teste instalável chamado:

```text
Balcao-Seguro-v1.1.5-github-debug.apk
```
