#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "============================================"
echo " Balcão Seguro — preparar cache uma vez"
echo "============================================"

echo "Este é o ÚNICO script que usa internet."
echo "Depois dele, os scripts OFFLINE tentam usar apenas cache local."
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo "ERRO: Node.js não encontrado. Instale Node antes."
  exit 1
fi

echo "== Baixando dependências npm =="
npm install

echo "== Ajustando dependências Expo =="
npx expo install --fix || true

echo "== Gerando Android nativo =="
./node_modules/.bin/expo prebuild -p android

echo "== Aquecendo Gradle Android =="
if [ -d "android" ]; then
  cd android
  chmod +x ./gradlew
  ./gradlew assembleRelease || true
  cd ..
fi

if [[ "$(uname)" == "Darwin" ]]; then
  echo "== Gerando iOS nativo =="
  ./node_modules/.bin/expo prebuild -p ios
  if [ -d "ios" ] && command -v pod >/dev/null 2>&1; then
    cd ios
    pod install || true
    cd ..
  fi
fi

echo ""
echo "Cache preparado. Agora tente:"
echo "./BUILD_ANDROID_APK_OFFLINE.command"
echo "./GERAR_IOS_XCODE_OFFLINE.command"
