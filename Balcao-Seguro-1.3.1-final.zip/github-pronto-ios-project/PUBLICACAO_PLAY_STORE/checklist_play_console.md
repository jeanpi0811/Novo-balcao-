# Checklist Play Console — Balcão Seguro

- [ ] Criar/confirmar conta Google Play Console
- [ ] Criar app com nome Balcão Seguro
- [ ] Categoria: Medical / Saúde e fitness
- [ ] Informar contato de suporte: WhatsApp (54) 99142-7519 ou e-mail público
- [ ] Publicar política de privacidade em URL acessível
- [ ] Preencher Segurança dos dados
- [ ] Preencher classificação indicativa
- [ ] Enviar screenshots reais do app em celular Android
- [ ] Enviar ícone 512×512
- [ ] Enviar gráfico de recurso 1024×500, se exigido
- [ ] Gerar AAB com `./03_GERAR_AAB_PLAY_STORE_ASSINADO.command`
- [ ] Enviar o AAB assinado do release **1.2.8**
- [ ] Fazer teste fechado/interno antes da produção
- [ ] Testar app offline em aparelho real
- [ ] Validar textos farmacêuticos e base de medicamentos
