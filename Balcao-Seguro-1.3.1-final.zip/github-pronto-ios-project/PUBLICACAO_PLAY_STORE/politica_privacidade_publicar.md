# Política de Privacidade — Balcão Seguro

Última atualização: 23/06/2026

O Balcão Seguro é um aplicativo de apoio ao atendimento farmacêutico, desenvolvido para uso local/offline.

## Dados armazenados
O app pode salvar registros de atendimento diretamente no aparelho do usuário. Esses registros são armazenados localmente e não são enviados automaticamente para servidor externo nesta versão.

## Compartilhamento
Quando o usuário usa uma função de compartilhamento, ele escolhe manualmente o destino do conteúdo. Nesse caso, o compartilhamento passa a depender do app escolhido pelo usuário, como WhatsApp, e-mail ou outro serviço.

## Dados sensíveis
O usuário deve evitar registrar informações pessoais sensíveis desnecessárias. O app é uma ferramenta de apoio e organização, não um prontuário eletrônico completo.

## Internet e servidores
Esta versão foi preparada para funcionar sem login, sem conta e sem envio automático de dados a servidores do desenvolvedor.

## Segurança do aparelho
Como os dados ficam no próprio aparelho, a segurança depende também de senha, bloqueio de tela, backups e proteção do dispositivo.

## Responsável e suporte
Responsável pelo conteúdo farmacêutico inicial: Jean Pierre Andres — CRF/RS 15974.
Suporte: WhatsApp (54) 99142-7519.

## Alterações
Esta política pode ser atualizada em versões futuras, especialmente se o app passar a usar servidor, login, sincronização ou recursos online.
