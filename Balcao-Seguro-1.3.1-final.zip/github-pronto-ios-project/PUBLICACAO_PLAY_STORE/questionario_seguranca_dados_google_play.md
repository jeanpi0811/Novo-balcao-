# Rascunho — Segurança dos dados no Google Play

Use este arquivo como base para responder ao formulário do Google Play Console. Confirme tudo antes de publicar.

## O app coleta dados?
Resposta sugerida para esta versão: **Não coleta dados automaticamente para servidor externo**.

## O app compartilha dados com terceiros?
Resposta sugerida: **Não compartilha automaticamente**. O usuário pode compartilhar manualmente registros usando outros apps do aparelho.

## Dados são criptografados em trânsito?
Como não há envio automático nesta versão, não se aplica ao fluxo principal. Se futuramente usar servidor, implementar HTTPS e revisar esta resposta.

## Usuário pode solicitar exclusão dos dados?
Sim, dentro do app existe função para limpar registros locais. Também é possível remover o app do aparelho.

## Tipos de dados locais possíveis
- Registros de atendimento digitados pelo usuário
- Informações de triagem
- Observações inseridas manualmente

## Observação
Se qualquer recurso online for adicionado, este questionário deve ser refeito.
