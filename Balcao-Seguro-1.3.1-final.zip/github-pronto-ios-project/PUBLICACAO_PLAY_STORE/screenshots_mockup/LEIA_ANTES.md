# Mockups de screenshots

Estes arquivos são rascunhos visuais para planejamento da página da Play Store. O ideal é substituir por screenshots reais capturados do APK final rodando em Android físico.

Arquivos:
- `01_home_mockup.png`
- `02_triagem_mockup.png`
- `03_medicamentos_mockup.png`
