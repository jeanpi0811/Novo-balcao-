# Validação clínica — lote 1 prioritário

## Medicamentos incluídos

Paracetamol, dipirona, ibuprofeno, naproxeno, ácido acetilsalicílico, loratadina, cetirizina, fexofenadina, omeprazol, pantoprazol, famotidina, simeticona, loperamida, sais de reidratação oral, metoclopramida, ondansetrona, amoxicilina, azitromicina, diclofenaco, nimesulida, dexametasona, dexclorfeniramina, butilescopolamina, mebendazol, fluconazol, salbutamol e ambroxol.

## O que já está pronto

Cada item possui:

- princípio ativo;
- classe;
- tarja aproximada por uso comum, exigindo conferência do produto específico;
- alertas de balcão;
- contraindicações/cuidados iniciais;
- perguntas-chave;
- sinais de alerta;
- critérios de encaminhamento;
- fontes regulatórias/assistenciais para validação.

## O que ainda falta para transformar em `validado`

Para cada produto específico:

1. consultar o produto no Sistema de Consultas da Anvisa;
2. confirmar número de registro, detentor, situação e apresentação;
3. abrir a bula profissional no Bulário Eletrônico;
4. conferir contraindicações, advertências, interações, população especial e posologia;
5. registrar `numeroRegistroAnvisa`, `detentorRegistro`, `dataVencimentoRegistro`;
6. trocar `statusValidacao` para `validado` somente se `bulaProfissionalConferida=true` e `escopoValidacao=produto_especifico`.

## Regra de ouro

O app pode estar bom para piloto e teste profissional interno com `pre_validado`, mas para divulgação ampla como apoio assistencial, o ideal é pelo menos os medicamentos mais usados estarem como `validado` por produto específico.
