# Balcão Seguro

Aplicativo offline de apoio ao atendimento farmacêutico no balcão.

Esta versão foi reorganizada para ficar mais didática e menos confusa:

- navegação por abas inferiores;
- atendimento guiado com perfil do paciente;
- seleção de faixa/condição: adulto, criança, idoso, gestante ou lactante;
- fatores de risco antes da triagem;
- busca de medicamentos com detalhes expansíveis;
- nova aba de interações medicamentosas;
- registros locais salvos no aparelho;
- área “Mais” com sobre, termos, privacidade, fontes e troca segura;
- novo ícone aplicado ao projeto.

## Abas

1. **Início** — atalhos e resumo geral.
2. **Atendimento** — fluxo de atendimento guiado.
3. **Medicamentos** — busca local offline.
4. **Interações** — checagem inicial entre dois medicamentos.
5. **Mais** — registros, troca segura, sobre, termos, privacidade e fontes.

## Gerar APK direto

No Terminal, dentro da pasta do projeto:

```bash
chmod +x *.command
./GERAR_APK_FINAL_REORGANIZADO.command
```

Também pode usar:

```bash
./02_GERAR_APK_DIRETO_ASSINADO.command
```

Arquivo esperado (o nome pode variar conforme o script):

```text
android/app/build/outputs/apk/release/app-release.apk
```

Esse APK pode ser copiado para o Android físico e instalado manualmente.

## Instalar no Android via cabo

Com o celular conectado e depuração USB ativa:

```bash
adb install -r Balcao-Seguro-v1.0.0-final.apk
```

## Aviso profissional

O Balcão Seguro é ferramenta de apoio e organização. Não substitui julgamento farmacêutico, bula profissional, protocolos institucionais, legislação sanitária nem atendimento médico quando indicado.

Responsável pelo conteúdo inicial:

Jean Pierre Andres — CRF/RS 15974.
