@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo == Balcao Seguro: corrigir erro Gradle signingConfig ==
if exist android\.gradle rmdir /s /q android\.gradle
if exist android\app\build rmdir /s /q android\app\build
if exist android\build rmdir /s /q android\build
python scripts\patch_android_signing.py
echo.
echo Agora rode COMPILAR_BALCAO_SEGURO_WINDOWS.bat ou o script de build final.
pause
