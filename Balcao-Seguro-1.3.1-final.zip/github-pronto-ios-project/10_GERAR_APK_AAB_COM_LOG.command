#!/bin/bash
set -e
cd "$(dirname "$0")"
LOG="build-final-etapa5-$(date +%Y%m%d-%H%M%S).log"
echo "== Balcão Seguro: APK + AAB final com log ==" | tee "$LOG"
{
  echo "Projeto: $(pwd)"
  echo "Data: $(date)"
  echo "Node: $(node -v 2>/dev/null || echo ausente)"
  echo "NPM: $(npm -v 2>/dev/null || echo ausente)"
  echo "Java: $(java -version 2>&1 | head -1 || echo ausente)"
  echo "ANDROID_HOME=${ANDROID_HOME:-vazio}"
  echo
  ./09_VALIDAR_PRE_BUILD.command
  echo
  echo "Gerando APK assinado..."
  ./02_GERAR_APK_DIRETO_ASSINADO.command
  echo
  echo "Gerando AAB Play Store..."
  ./03_GERAR_AAB_PLAY_STORE_ASSINADO.command
  echo
  echo "Verificando APK..."
  ./05_VERIFICAR_APK_GERADO.command || true
} 2>&1 | tee -a "$LOG"
echo "Log salvo em: $LOG"
