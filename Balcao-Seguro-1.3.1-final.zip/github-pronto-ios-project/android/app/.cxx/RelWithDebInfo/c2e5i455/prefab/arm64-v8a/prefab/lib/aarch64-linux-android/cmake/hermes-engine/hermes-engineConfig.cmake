if(NOT TARGET hermes-engine::hermesvm)
add_library(hermes-engine::hermesvm SHARED IMPORTED)
set_target_properties(hermes-engine::hermesvm PROPERTIES
    IMPORTED_LOCATION "/home/ubuntu/.gradle/caches/8.13/transforms/6ae65d78b9e14f802b2a16c323373bf8/transformed/hermes-android-250829098.0.10-release/prefab/modules/hermesvm/libs/android.arm64-v8a/libhermesvm.so"
    INTERFACE_INCLUDE_DIRECTORIES "/home/ubuntu/.gradle/caches/8.13/transforms/6ae65d78b9e14f802b2a16c323373bf8/transformed/hermes-android-250829098.0.10-release/prefab/modules/hermesvm/include"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

