#!/bin/bash
bash ./scripts/fix_gradle_wrapper.sh 2>/dev/null || true
set -euo pipefail
cd "$(dirname "$0")"

echo "============================================"
echo " Balcão Seguro — APK reorganizado"
echo "============================================"
echo "Gera APK release direto para instalar no Android físico."
echo "Não gera AAB/Play Store."
echo ""

./02_GERAR_APK_DIRETO_ASSINADO.command
