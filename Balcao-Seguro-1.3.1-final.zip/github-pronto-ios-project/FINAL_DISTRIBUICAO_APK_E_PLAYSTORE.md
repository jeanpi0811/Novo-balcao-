# Balcão Seguro — distribuição final: APK direto + Play Store

## Caminho C escolhido

Este pacote está preparado para dois fluxos:

1. **APK direto assinado**: para instalar manualmente em Android físico, testar e distribuir fora da Play Store.
2. **AAB Play Store assinado**: para enviar no Google Play Console.

## Ordem recomendada

```bash
chmod +x *.command scripts/*.sh
./00_VALIDAR_AMBIENTE_ANDROID.command
./01_PREPARAR_DEPENDENCIAS.command
./02_GERAR_APK_DIRETO_ASSINADO.command
```

Depois de testar o APK no Android:

```bash
./03_GERAR_AAB_PLAY_STORE_ASSINADO.command
```

Ou gere os dois de uma vez:

```bash
./GERAR_APK_E_AAB_FINAL.command
```

## Arquivos finais esperados

- `Balcao-Seguro-v1.0.0-final.apk`
- `Balcao-Seguro-v1.0.0-playstore.aab`

## Assinatura

Na primeira execução, o script cria uma chave release em:

```text
android/app/balcao-seguro-upload-key.keystore
```

Faça backup dessa chave. Sem ela, pode ser difícil atualizar o app depois usando o mesmo pacote.

## Pacote Android

```text
br.com.farmabolso.balcaoseguro
```

## Versão

```text
1.0.0 — versionCode 1
```

## Observação importante

A versão foi desenhada para funcionar offline, sem login e sem envio automático de dados. Mesmo assim, antes de uso amplo, valide medicamentos, protocolos e textos contra fontes oficiais, bulas e regras profissionais vigentes.
