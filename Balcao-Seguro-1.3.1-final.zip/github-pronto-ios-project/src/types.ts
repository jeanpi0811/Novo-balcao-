export type Gravidade = 'verde' | 'amarelo' | 'vermelho';

export type PerguntaTriagem = {
  id: string;
  texto: string;
  gravidade: Exclude<Gravidade, 'verde'>;
  motivo: string;
};

export type ProtocoloTriagem = {
  id: string;
  titulo: string;
  categoria: string;
  resumo: string;
  perguntas: PerguntaTriagem[];
  orientacaoVerde: string[];
  orientacaoAmarela: string[];
  condutaVermelha: string[];
  mipPossiveis: string[];
  evitar: string[];
};

export type RespostaTriagem = Record<string, boolean>;

export type ResultadoTriagem = {
  gravidade: Gravidade;
  titulo: string;
  motivos: string[];
  condutas: string[];
  mipPossiveis: string[];
  evitar: string[];
};

export type StatusValidacaoMedicamento = 'validado' | 'pre_validado' | 'parcial' | 'pendente' | 'desatualizado';

export type EscopoValidacaoMedicamento = 'principio_ativo' | 'produto_especifico' | 'classe_terapeutica' | 'nao_definido';

export type TipoFonteMedicamento =
  | 'ANVISA_DADOS_ABERTOS'
  | 'ANVISA_CONSULTAS'
  | 'ANVISA_BULARIO'
  | 'BULA_PROFISSIONAL'
  | 'PROTOCOLO_INTERNO'
  | 'CURADORIA_FARMACEUTICA'
  | 'OUTRA';

export type FonteMedicamento = {
  tipo: TipoFonteMedicamento;
  titulo: string;
  url?: string;
  acessadoEm?: string;
  observacao?: string;
};


export type ClassificacaoGrupoEspecial =
  | 'permitido com orientação'
  | 'usar com cautela'
  | 'evitar sem avaliação profissional'
  | 'contraindicado'
  | 'não encontrado em fonte oficial';

export type GrupoEspecialMedicamento = {
  classificacao: ClassificacaoGrupoEspecial;
  observacao: string;
};

export type InteracaoMedicamentoEnriquecida = {
  com: string;
  classe_ou_medicamento: string;
  gravidade: 'leve' | 'moderada' | 'grave' | 'contraindicada';
  mecanismo_simples: string;
  consequencia: string;
  orientacao_segura: string;
  fonte: string;
};

export type FonteMedicamentoEnriquecida = {
  nome: string;
  url?: string;
  data_acesso: string;
  resumo_usado: string;
  nivel_confianca: 'alta' | 'média' | 'baixa';
};

export type EnriquecimentoMedicamento = {
  id: string;
  nome: string;
  principio_ativo: string;
  nomes_comerciais: string[];
  classe_terapeutica: string;
  formas: string[];
  vias: string[];
  concentracoes: string[];
  tipo_venda: string;
  tarja: string;
  uso_orientativo: {
    para_que_serve: string;
    indicacao_geral: string;
    observacao_nao_prescritiva: string;
  };
  alertas: {
    contraindicacoes: string[];
    cuidados: string[];
    sinais_alerta: string[];
    quando_encaminhar: string[];
  };
  grupos_especiais: {
    criancas: GrupoEspecialMedicamento;
    idosos: GrupoEspecialMedicamento;
    gestantes: GrupoEspecialMedicamento;
    lactantes: GrupoEspecialMedicamento;
    renal: GrupoEspecialMedicamento;
    hepatica: GrupoEspecialMedicamento;
    hipertensao: GrupoEspecialMedicamento;
    diabetes: GrupoEspecialMedicamento;
    cardiopatia: GrupoEspecialMedicamento;
    anticoagulantes: GrupoEspecialMedicamento;
    alergias: GrupoEspecialMedicamento;
  };
  interacoes: InteracaoMedicamentoEnriquecida[];
  efeitos_adversos: {
    comuns: string[];
    importantes: string[];
    alergia: string[];
    intoxicacao: string[];
    atendimento_imediato: string[];
  };
  triagem_farmaceutica: {
    perguntas_obrigatorias: string[];
    perguntas_recomendadas: string[];
    criterios_encaminhamento: string[];
  };
  resumo_leigo: {
    para_que_serve: string;
    quando_ter_cuidado: string;
    quando_procurar_atendimento: string;
    o_que_nao_fazer: string;
    perguntas_do_farmaceutico: string[];
  };
  aviso_responsabilidade: string;
  fontes: FonteMedicamentoEnriquecida[];
  status_validacao: {
    validado: boolean;
    pendencias: string[];
    observacoes: string;
  };
};

export type Medicamento = {
  id: string;
  nome: string;
  principioAtivo: string;
  classe: string;
  tarja: 'MIP' | 'Tarja vermelha' | 'Tarja preta' | 'Controle especial' | 'Outro';
  forma: string;
  dosagem: string;
  referencia?: string;
  genericos?: string[];
  similaresIntercambiaveis?: string[];
  alertas: string[];
  contraindicacoes: string[];
  statusValidacao?: StatusValidacaoMedicamento;
  numeroRegistroAnvisa?: string;
  situacaoRegistro?: string;
  categoriaRegulatoria?: string;
  detentorRegistro?: string;
  dataRegistro?: string;
  dataVencimentoRegistro?: string;
  revisadoEm?: string;
  revisadoPor?: string;
  fontes?: FonteMedicamento[];
  observacoesValidacao?: string[];
  escopoValidacao?: EscopoValidacaoMedicamento;
  bulaProfissionalConferida?: boolean;
  revisaoVenceEm?: string;
  perguntasChave?: string[];
  sinaisAlertaBalcao?: string[];
  quandoEncaminhar?: string[];
  enriquecimento?: EnriquecimentoMedicamento;
};

export type RegistroAtendimento = {
  id: string;
  dataISO: string;
  sintoma: string;
  gravidade: Gravidade;
  resumo: string;
  faixaEtaria?: 'nao_informada' | 'adulto' | 'crianca' | 'idoso' | 'gestante' | 'lactante';
  fatoresRisco?: string[];
};
