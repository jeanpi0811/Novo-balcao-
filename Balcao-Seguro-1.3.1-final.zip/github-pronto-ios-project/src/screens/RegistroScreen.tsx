import React from 'react';
import { Alert, Share, Text, StyleSheet, View } from 'react-native';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { theme } from '../styles/theme';
import { appInfo } from '../data/appInfo';
import { rotuloFaixaEtaria } from '../data/perfil';
import { ScreenName, tabFromScreen } from '../navigation';
import { RegistroAtendimento } from '../types';
import { formatarData, gravidadeEmoji } from '../utils/format';

type Props = {
  onNavigate: (screen: ScreenName) => void;
  registros: RegistroAtendimento[];
  onLimpar: () => void;
  carregado: boolean;
  activeScreen: ScreenName;
};

export function RegistroScreen({ onNavigate, registros, onLimpar, carregado, activeScreen }: Props) {
  async function compartilhar(registro: RegistroAtendimento) {
    await Share.share({
      message: `Balcão Seguro\n\nData: ${formatarData(registro.dataISO)}\nSintoma: ${registro.sintoma}\nClassificação: ${registro.gravidade.toUpperCase()}\nPerfil: ${rotuloFaixaEtaria(registro.faixaEtaria)}${registro.fatoresRisco?.length ? `\nRiscos: ${registro.fatoresRisco.join(', ')}` : ''}\n\nRegistro:\n${registro.resumo}\n\nAviso: registro de apoio. Não substitui avaliação profissional, bula, protocolos ou atendimento médico quando indicado.\nResponsável pelo conteúdo: ${appInfo.responsavelFarmaceutico} — ${appInfo.registroProfissional}. Suporte: ${appInfo.contatoSuporte}.`
    });
  }

  function confirmarLimpeza() {
    Alert.alert('Limpar registros?', 'Esta ação apaga os registros salvos neste aparelho.', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Limpar', style: 'destructive', onPress: onLimpar }
    ]);
  }

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <Title>Registros</Title>
      <Muted>Atendimentos salvos localmente no aparelho. Nada é enviado para servidor.</Muted>

      <PrimaryButton title="Novo atendimento" onPress={() => onNavigate('triagem')} />
      {!carregado && <Card><Body>Carregando registros...</Body></Card>}
      {carregado && registros.length === 0 && <Card><Body>Nenhum atendimento salvo ainda.</Body></Card>}

      {registros.map((registro) => (
        <Card key={registro.id}>
          <Subtitle>{gravidadeEmoji(registro.gravidade)} {registro.sintoma}</Subtitle>
          <Muted>{formatarData(registro.dataISO)}</Muted>
          <View style={styles.row}>
            <Text style={styles.gravidade}>{registro.gravidade.toUpperCase()}</Text>
            {registro.faixaEtaria ? <Text style={styles.profile}>{rotuloFaixaEtaria(registro.faixaEtaria)}</Text> : null}
          </View>
          {registro.fatoresRisco?.length ? <Muted>Riscos: {registro.fatoresRisco.join(' • ')}</Muted> : null}
          <Body>{registro.resumo}</Body>
          <PrimaryButton title="Compartilhar registro" onPress={() => compartilhar(registro)} variant="secondary" />
        </Card>
      ))}

      {registros.length > 0 && <PrimaryButton title="Limpar registros salvos" onPress={confirmarLimpeza} variant="danger" />}
    </Screen>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 8 },
  gravidade: { color: theme.colors.bg, backgroundColor: theme.colors.primary, fontWeight: '900', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 999, overflow: 'hidden' },
  profile: { color: theme.colors.text, backgroundColor: theme.colors.card2, borderWidth: 1, borderColor: theme.colors.border, fontWeight: '800', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 999, overflow: 'hidden' }
});
