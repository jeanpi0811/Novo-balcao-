import React, { useEffect, useRef } from 'react';
import { Animated, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { ActionTile } from '../components/ActionTile';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { Header } from '../components/Header';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle } from '../components/TextBits';
import { appInfo } from '../data/appInfo';
import { contarStatusValidacao } from '../data/baseMedicamentosInfo';
import { medicamentos } from '../data/medicamentos';
import { protocolos } from '../data/protocolos';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';

type Props = {
  onNavigate: (screen: ScreenName) => void;
  totalRegistros: number;
  activeScreen: ScreenName;
};

export function HomeScreen({ onNavigate, totalRegistros, activeScreen }: Props) {
  const statusBase = contarStatusValidacao(medicamentos);
  const { width } = useWindowDimensions();
  const wide = width >= 720;

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <HomeGlassBackdrop />
      <Header subtitle="Atendimento farmacêutico com mais clareza, segurança e registro local." />
      <AnimatedHomeIcon />

      <View style={wide ? styles.wideGrid : undefined}>
        <View style={wide ? styles.wideColumn : undefined}>
          <ActionTile icon="＋" title="Novo atendimento" body="Recurso Pro: comece pelo perfil do paciente, siga a triagem e salve o registro." onPress={() => onNavigate('atendimento')} tone="green" />
          <ActionTile icon="🔎" title="Buscar medicamento" body="Consulta básica livre: princípio ativo, alertas, contraindicações e status da base." onPress={() => onNavigate('medicamentos')} />
          <ActionTile icon="⚠️" title="Interações medicamentosas" body="Recurso Pro: checagem inicial entre medicamentos com checklist de orientação." onPress={() => onNavigate('interacoes')} tone="yellow" />
        </View>

        <View style={wide ? styles.wideColumn : undefined}>
          <Card>
            <Subtitle>Resumo rápido</Subtitle>
            <View style={styles.statsRow}>
              <Stat label="Protocolos" value={`${protocolos.length}`} />
              <Stat label="Medicamentos" value={`${medicamentos.length}`} />
              <Stat label="Registros" value={`${totalRegistros}`} />
            </View>
            <Muted>Base local: {statusBase.validado} validado(s), {statusBase.pre_validado} pré-validados, {statusBase.parcial} parciais e {statusBase.pendente} pendentes.</Muted>
          </Card>
        </View>
      </View>

      <Card>
        <Subtitle>Fluxo recomendado</Subtitle>
        <Step n="1" text="Identifique faixa etária e riscos do paciente." />
        <Step n="2" text="Use triagem guiada para sinais de alerta." />
        <Step n="3" text="Consulte medicamento, interação e possibilidade de troca." />
        <Step n="4" text="Registre a orientação e encaminhe quando necessário." />
      </Card>

      <Card>
        <Subtitle>Demonstração comercial</Subtitle>
        <Body>Esta versão está preparada para apresentação, testes internos e validação do fluxo Grátis/Pro.</Body>
        <Muted>O pagamento real ainda não está ativo. Recursos Pro podem ser liberados localmente pela Área Admin.</Muted>
      </Card>

      <Card>
        <Subtitle>Responsável pelo conteúdo</Subtitle>
        <Body>{appInfo.responsavelFarmaceutico} — {appInfo.registroProfissional}</Body>
        <Muted>Uso profissional de apoio. Não substitui julgamento farmacêutico, bula, protocolos locais ou atendimento médico quando indicado.</Muted>
      </Card>
    </Screen>
  );
}

function AnimatedHomeIcon() {
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(8)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(opacity, { toValue: 1, duration: 420, useNativeDriver: true }),
      Animated.timing(translateY, { toValue: 0, duration: 420, useNativeDriver: true }),
    ]).start();
  }, [opacity, translateY]);

  return (
    <Animated.View style={[styles.homeIconWrap, { opacity, transform: [{ translateY }] }]}>
      <Animated.Image
        source={require('../../assets/home-icon-transparent.png')}
        accessibilityLabel="Balcão Seguro"
        resizeMode="contain"
        style={styles.homeIcon}
      />
    </Animated.View>
  );
}

function HomeGlassBackdrop() {
  return (
    <View pointerEvents="none" style={styles.backdrop}>
      <View style={[styles.glow, styles.glowPrimary]} />
      <View style={[styles.glow, styles.glowGreen]} />
      <View style={styles.softLine} />
    </View>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

function Step({ n, text }: { n: string; text: string }) {
  return (
    <View style={styles.step}>
      <Text style={styles.stepBadge}>{n}</Text>
      <Text style={styles.stepText}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    position: 'absolute',
    top: -60,
    left: -24,
    right: -24,
    height: 410,
  },
  glow: {
    position: 'absolute',
    borderRadius: 999,
    borderWidth: 1,
  },
  glowPrimary: {
    width: 270,
    height: 270,
    right: -112,
    top: 10,
    backgroundColor: 'rgba(56, 189, 248, 0.10)',
    borderColor: 'rgba(56, 189, 248, 0.20)',
  },
  glowGreen: {
    width: 190,
    height: 190,
    left: -88,
    top: 168,
    backgroundColor: 'rgba(34, 197, 94, 0.07)',
    borderColor: 'rgba(34, 197, 94, 0.14)',
  },
  softLine: {
    position: 'absolute',
    left: 18,
    right: 18,
    top: 330,
    height: 1,
    backgroundColor: 'rgba(148, 163, 184, 0.12)',
  },
  homeIconWrap: { alignItems: 'center', justifyContent: 'center', marginTop: 4, marginBottom: 14 },
  homeIcon: { width: 154, height: 154 },
  wideGrid: { flexDirection: 'row', gap: theme.spacing.md, alignItems: 'stretch' },
  wideColumn: { flex: 1 },
  statsRow: { flexDirection: 'row', gap: theme.spacing.sm, marginBottom: theme.spacing.md },
  stat: { flex: 1, backgroundColor: 'rgba(31, 41, 55, 0.72)', borderRadius: theme.radius.md, padding: theme.spacing.sm, borderWidth: 1, borderColor: 'rgba(148, 163, 184, 0.22)' },
  statValue: { color: theme.colors.primary, fontSize: 20, fontWeight: '900', textAlign: 'center' },
  statLabel: { color: theme.colors.muted, fontSize: 11, textAlign: 'center', marginTop: 2 },
  step: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, marginTop: 10 },
  stepBadge: { width: 24, height: 24, borderRadius: 12, backgroundColor: theme.colors.primary, color: theme.colors.bg, textAlign: 'center', lineHeight: 24, fontWeight: '900', overflow: 'hidden' },
  stepText: { color: theme.colors.muted, flex: 1, lineHeight: 21, fontWeight: '600' }
});
