import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { fatoresClinicos, FaixaEtaria, faixasEtarias, rotuloFaixaEtaria } from '../data/perfil';
import { protocolos } from '../data/protocolos';
import { avaliarTriagem } from '../logic/triagem';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';
import { ProtocoloTriagem, RegistroAtendimento, RespostaTriagem } from '../types';

type Props = {
  onNavigate: (screen: ScreenName) => void;
  onSalvarRegistro: (registro: RegistroAtendimento) => void;
  activeScreen: ScreenName;
};

export function TriagemScreen({ onNavigate, onSalvarRegistro, activeScreen }: Props) {
  const [etapa, setEtapa] = useState<'perfil' | 'sintoma' | 'perguntas'>('perfil');
  const [faixaEtaria, setFaixaEtaria] = useState<FaixaEtaria>('adulto');
  const [riscos, setRiscos] = useState<string[]>([]);
  const [protocolo, setProtocolo] = useState<ProtocoloTriagem | null>(null);
  const [respostas, setRespostas] = useState<RespostaTriagem>({});
  const perguntasRespondidas = protocolo ? protocolo.perguntas.filter((pergunta) => typeof respostas[pergunta.id] === 'boolean').length : 0;
  const triagemCompleta = protocolo ? perguntasRespondidas === protocolo.perguntas.length : false;
  const resultado = useMemo(() => (protocolo && triagemCompleta ? avaliarTriagem(protocolo, respostas) : null), [protocolo, respostas, triagemCompleta]);

  function alternarRisco(item: string) {
    setRiscos((prev) => prev.includes(item) ? prev.filter((r) => r !== item) : [...prev, item]);
  }

  function selecionar(item: ProtocoloTriagem) {
    setProtocolo(item);
    setRespostas({});
    setEtapa('perguntas');
  }

  function salvar() {
    if (!protocolo || !resultado) return;

    const resumo = [
      `Perfil: ${rotuloFaixaEtaria(faixaEtaria)}${riscos.length ? `; riscos: ${riscos.join(', ')}` : '; sem risco marcado'}.`,
      `${resultado.titulo}.`,
      `Motivos: ${resultado.motivos.join(' | ')}.`,
      `Condutas: ${resultado.condutas.join(' | ')}.`
    ].join(' ');

    onSalvarRegistro({
      id: `${Date.now()}`,
      dataISO: new Date().toISOString(),
      sintoma: protocolo.titulo,
      gravidade: resultado.gravidade,
      resumo,
      faixaEtaria,
      fatoresRisco: riscos
    });
  }

  if (etapa === 'perfil') {
    return (
      <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
        <Title>Novo atendimento</Title>
        <Muted>Primeiro defina o perfil. Isso evita orientar criança, gestante, idoso frágil ou paciente de risco como se fosse adulto saudável.</Muted>

        <Card>
          <Subtitle>1. Faixa/condição do paciente</Subtitle>
          {faixasEtarias.map((faixa) => (
            <Pressable key={faixa.id} onPress={() => setFaixaEtaria(faixa.id)} style={[styles.option, faixaEtaria === faixa.id && styles.optionSelected]}>
              <View style={styles.optionText}>
                <Text style={styles.optionTitle}>{faixa.label}</Text>
                <Text style={styles.optionBody}>{faixa.descricao}</Text>
              </View>
              <Text style={styles.check}>{faixaEtaria === faixa.id ? '✓' : ''}</Text>
            </Pressable>
          ))}
        </Card>

        <Card>
          <Subtitle>2. Riscos relevantes</Subtitle>
          <Muted>Marque tudo que estiver presente. Esses dados entram no registro.</Muted>
          <View style={styles.grid}>
            {fatoresClinicos.map((fator) => {
              const marcado = riscos.includes(fator);
              return <Pressable key={fator} onPress={() => alternarRisco(fator)}><Text style={[styles.risk, marcado && styles.riskSelected]}>{marcado ? '✓ ' : ''}{fator}</Text></Pressable>;
            })}
          </View>
        </Card>

        <PrimaryButton title="Continuar para o sintoma" onPress={() => setEtapa('sintoma')} />
        <PrimaryButton title="Cancelar atendimento" onPress={() => onNavigate('atendimento')} variant="secondary" />
      </Screen>
    );
  }

  if (etapa === 'sintoma') {
    return (
      <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
        <Title>Escolha o sintoma</Title>
        <Muted>Perfil definido: {rotuloFaixaEtaria(faixaEtaria)}{riscos.length ? ` • ${riscos.length} risco(s) marcado(s)` : ''}.</Muted>
        {protocolos.map((item) => (
          <Pressable key={item.id} onPress={() => selecionar(item)}>
            <Card>
              <Subtitle>{item.titulo}</Subtitle>
              <Muted>{item.categoria}</Muted>
              <Body>{item.resumo}</Body>
            </Card>
          </Pressable>
        ))}
        <PrimaryButton title="Editar perfil" onPress={() => setEtapa('perfil')} variant="secondary" />
        <PrimaryButton title="Voltar" onPress={() => onNavigate('atendimento')} variant="secondary" />
      </Screen>
    );
  }

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <Title>{protocolo?.titulo}</Title>
      <Muted>{protocolo?.resumo}</Muted>
      <Card>
        <Subtitle>Perfil do paciente</Subtitle>
        <Body>{rotuloFaixaEtaria(faixaEtaria)}</Body>
        <Muted>{riscos.length ? riscos.join(' • ') : 'Nenhum risco marcado.'}</Muted>
      </Card>
      <Muted>Respondidas: {perguntasRespondidas}/{protocolo?.perguntas.length ?? 0}. O resultado só aparece depois de responder tudo.</Muted>

      {protocolo?.perguntas.map((pergunta) => {
        const valor = respostas[pergunta.id];
        return (
          <Card key={pergunta.id}>
            <Body>{pergunta.texto}</Body>
            <View style={styles.row}>
              <PrimaryButton title="Sim" onPress={() => setRespostas((prev) => ({ ...prev, [pergunta.id]: true }))} variant={valor === true ? 'danger' : 'secondary'} style={styles.choice} />
              <PrimaryButton title="Não" onPress={() => setRespostas((prev) => ({ ...prev, [pergunta.id]: false }))} variant={valor === false ? 'success' : 'secondary'} style={styles.choice} />
            </View>
          </Card>
        );
      })}

      {!triagemCompleta && (
        <Card>
          <Subtitle>Finalize a triagem</Subtitle>
          <Body>Responda todas as perguntas para evitar classificação verde antes da hora.</Body>
        </Card>
      )}

      {resultado && (
        <Card>
          <Text style={[styles.badge, styles[resultado.gravidade]]}>{resultado.gravidade.toUpperCase()}</Text>
          <Subtitle>{resultado.titulo}</Subtitle>
          <Section title="Motivos" items={resultado.motivos} />
          <Section title="Conduta sugerida" items={resultado.condutas} />
          {resultado.mipPossiveis.length > 0 && <Section title="MIP/medidas possíveis" items={resultado.mipPossiveis} />}
          <Section title="Evitar" items={resultado.evitar} />
          {(faixaEtaria !== 'adulto' || riscos.length > 0) && <Section title="Atenção pelo perfil" items={[`Perfil marcado: ${rotuloFaixaEtaria(faixaEtaria)}.`, ...(riscos.length ? riscos : ['Sem risco adicional marcado.'])]} />}
          <PrimaryButton title="Salvar registro deste atendimento" onPress={salvar} />
        </Card>
      )}

      <PrimaryButton title="Escolher outro sintoma" onPress={() => setEtapa('sintoma')} variant="secondary" />
      <PrimaryButton title="Editar perfil" onPress={() => setEtapa('perfil')} variant="secondary" />
      <PrimaryButton title="Voltar ao atendimento" onPress={() => onNavigate('atendimento')} variant="secondary" />
    </Screen>
  );
}

function Section({ title, items }: { title: string; items: string[] }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {items.map((item, index) => <Text key={`${title}-${index}`} style={styles.item}>• {item}</Text>)}
    </View>
  );
}

const styles = StyleSheet.create({
  option: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: theme.colors.border, borderRadius: theme.radius.md, padding: 12, marginBottom: 8, backgroundColor: theme.colors.card2 },
  optionSelected: { borderColor: theme.colors.primary, backgroundColor: 'rgba(56, 189, 248, 0.14)' },
  optionText: { flex: 1 },
  optionTitle: { color: theme.colors.text, fontWeight: '900', fontSize: 15 },
  optionBody: { color: theme.colors.muted, lineHeight: 18, marginTop: 3 },
  check: { color: theme.colors.primary, fontWeight: '900', fontSize: 20, marginLeft: 10 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10 },
  risk: { color: theme.colors.text, backgroundColor: theme.colors.card2, borderWidth: 1, borderColor: theme.colors.border, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 999, overflow: 'hidden', fontWeight: '700' },
  riskSelected: { borderColor: theme.colors.primary, color: theme.colors.primary, backgroundColor: 'rgba(56, 189, 248, 0.14)' },
  row: { flexDirection: 'row', gap: 10, marginTop: 10 },
  choice: { flex: 1 },
  badge: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, overflow: 'hidden', color: theme.colors.bg, fontWeight: '900', marginBottom: 8 },
  verde: { backgroundColor: theme.colors.green },
  amarelo: { backgroundColor: theme.colors.yellow },
  vermelho: { backgroundColor: theme.colors.red },
  section: { marginTop: 12 },
  sectionTitle: { color: theme.colors.text, fontWeight: '800', marginBottom: 4 },
  item: { color: theme.colors.muted, lineHeight: 20 }
});
