import React, { useMemo, useState } from 'react';
import { Alert, Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Card } from '../components/Card';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { appInfo } from '../data/appInfo';
import { declaracoesAceite, termosAceiteInicial } from '../data/legal';
import { VERSAO_TERMOS_ACEITE } from '../storage/termos';
import { theme } from '../styles/theme';

type Props = {
  onAceitar: () => Promise<void> | void;
};

export function AceiteInicialScreen({ onAceitar }: Props) {
  const [marcados, setMarcados] = useState<boolean[]>(declaracoesAceite.map(() => false));
  const [salvando, setSalvando] = useState(false);

  const todosMarcados = useMemo(() => marcados.every(Boolean), [marcados]);

  function alternar(index: number) {
    setMarcados((atuais) => atuais.map((valor, i) => (i === index ? !valor : valor)));
  }

  async function aceitar() {
    if (!todosMarcados || salvando) return;
    setSalvando(true);
    try {
      await onAceitar();
    } finally {
      setSalvando(false);
    }
  }

  function naoAceitar() {
    Alert.alert(
      'Aceite necessário',
      'Para proteger o usuário e o responsável pelo app, o Balcão Seguro só pode ser usado depois da leitura e aceite dos termos de responsabilidade.'
    );
  }

  return (
    <View style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <Image source={require('../../assets/icon.png')} style={styles.logo} />
          <View style={styles.headerText}>
            <Title>Termos e responsabilidade</Title>
            <Muted>Leia e aceite antes de usar o {appInfo.nome}.</Muted>
          </View>
        </View>

        <Card>
          <Subtitle>Antes de continuar</Subtitle>
          <Body>
            Este aplicativo é somente uma ferramenta de apoio e orientação. Ele não substitui diagnóstico, prescrição, consulta médica, avaliação presencial, bula, protocolos oficiais ou responsabilidade profissional.
          </Body>
        </Card>

        <Card>
          <Subtitle>Termos principais</Subtitle>
          {termosAceiteInicial.map((item, index) => (
            <Text key={`termo-${index}`} style={styles.item}>• {item}</Text>
          ))}
        </Card>

        <Card>
          <Subtitle>Declarações obrigatórias</Subtitle>
          <Muted>Marque todas para liberar o uso do aplicativo.</Muted>
          <View style={styles.checkList}>
            {declaracoesAceite.map((item, index) => (
              <Pressable key={`declaracao-${index}`} onPress={() => alternar(index)} style={({ pressed }) => [styles.checkRow, pressed && styles.pressed]}>
                <View style={[styles.box, marcados[index] && styles.boxOn]}>
                  <Text style={styles.checkMark}>{marcados[index] ? '✓' : ''}</Text>
                </View>
                <Text style={styles.checkText}>{item}</Text>
              </Pressable>
            ))}
          </View>
        </Card>

        <Card>
          <Subtitle>Registro do aceite</Subtitle>
          <Muted>O aceite fica salvo apenas no aparelho para liberar o app. Versão dos termos: {VERSAO_TERMOS_ACEITE}.</Muted>
        </Card>

        <Pressable onPress={aceitar} disabled={!todosMarcados || salvando} style={({ pressed }) => [styles.acceptButton, (!todosMarcados || salvando) && styles.disabledButton, pressed && todosMarcados && styles.pressed]}>
          <Text style={styles.acceptText}>{salvando ? 'Salvando aceite...' : 'Li, entendi e aceito os termos'}</Text>
        </Pressable>

        <Pressable onPress={naoAceitar} style={({ pressed }) => [styles.declineButton, pressed && styles.pressed]}>
          <Text style={styles.declineText}>Não aceito</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.colors.bg },
  content: { padding: theme.spacing.lg, paddingBottom: 36 },
  header: { flexDirection: 'row', alignItems: 'center', gap: theme.spacing.md, marginBottom: theme.spacing.md },
  logo: { width: 72, height: 72, borderRadius: 20 },
  headerText: { flex: 1 },
  item: { color: theme.colors.muted, lineHeight: 21, marginBottom: 8 },
  checkList: { marginTop: theme.spacing.md, gap: theme.spacing.sm },
  checkRow: {
    flexDirection: 'row',
    gap: theme.spacing.sm,
    alignItems: 'flex-start',
    backgroundColor: 'rgba(15, 23, 42, 0.72)',
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.md,
    padding: theme.spacing.md
  },
  box: {
    width: 26,
    height: 26,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: theme.colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 1
  },
  boxOn: { backgroundColor: theme.colors.green, borderColor: theme.colors.green },
  checkMark: { color: theme.colors.white, fontWeight: '900', fontSize: 17, lineHeight: 20 },
  checkText: { flex: 1, color: theme.colors.text, fontSize: 14, lineHeight: 20, fontWeight: '600' },
  acceptButton: {
    backgroundColor: theme.colors.green,
    borderRadius: theme.radius.lg,
    paddingVertical: 15,
    paddingHorizontal: theme.spacing.md,
    alignItems: 'center',
    marginTop: 4
  },
  disabledButton: { opacity: 0.38 },
  acceptText: { color: theme.colors.white, fontWeight: '900', fontSize: 16, textAlign: 'center' },
  declineButton: { alignItems: 'center', paddingVertical: 14 },
  declineText: { color: theme.colors.muted, fontWeight: '800' },
  pressed: { opacity: 0.72 }
});
