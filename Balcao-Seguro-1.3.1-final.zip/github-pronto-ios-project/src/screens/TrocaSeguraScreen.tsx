import React from 'react';
import { Text, StyleSheet, View } from 'react-native';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { medicamentos } from '../data/medicamentos';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';

const medicamentosComTroca = medicamentos
  .filter((medicamento) => medicamento.referencia || (medicamento.genericos?.length ?? 0) > 0 || (medicamento.similaresIntercambiaveis?.length ?? 0) > 0)
  .slice(0, 40);

type Props = { onNavigate: (screen: ScreenName) => void; activeScreen: ScreenName };

export function TrocaSeguraScreen({ onNavigate, activeScreen }: Props) {
  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <Title>Troca segura</Title>
      <Muted>Referência, genéricos e similares cadastrados na base local. Use como checklist, não como autorização automática.</Muted>

      <Card>
        <Subtitle>Checklist antes da substituição</Subtitle>
        <Section title="Conferir sempre" items={['Mesmo princípio ativo', 'Mesma concentração', 'Mesma forma farmacêutica', 'Mesma via de administração', 'Restrições da receita e legislação', 'Intercambialidade quando aplicável']} />
      </Card>

      {medicamentosComTroca.map((medicamento) => (
        <Card key={medicamento.id}>
          <Subtitle>{medicamento.nome}</Subtitle>
          <Body>Princípio ativo: {medicamento.principioAtivo}</Body>
          <Body>Referência: {medicamento.referencia || 'Não informado'}</Body>
          <Section title="Genéricos" items={medicamento.genericos ?? []} />
          <Section title="Similares intercambiáveis" items={medicamento.similaresIntercambiaveis ?? []} empty="Ainda não cadastrado nesta base local." />
          <Text style={styles.warning}>Conferir dose, forma, concentração, apresentação, restrições e prescrição antes da substituição.</Text>
        </Card>
      ))}

      {medicamentosComTroca.length === 0 && <Card><Body>Não há medicamentos com dados de troca cadastrados.</Body></Card>}
      <PrimaryButton title="Voltar para medicamentos" onPress={() => onNavigate('medicamentos')} variant="secondary" />
    </Screen>
  );
}

function Section({ title, items, empty = 'Não informado.' }: { title: string; items: string[]; empty?: string }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {items.length === 0 ? <Text style={styles.item}>• {empty}</Text> : items.map((item, index) => <Text key={`${title}-${index}`} style={styles.item}>• {item}</Text>)}
    </View>
  );
}

const styles = StyleSheet.create({
  section: { marginTop: 12 },
  sectionTitle: { color: theme.colors.text, fontWeight: '800', marginBottom: 4 },
  item: { color: theme.colors.muted, lineHeight: 20 },
  warning: { color: theme.colors.yellow, marginTop: 12, lineHeight: 20 }
});
