import React, { useState } from 'react';
import { Alert, StyleSheet, Text, TextInput, View } from 'react-native';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { appInfo } from '../data/appInfo';
import { contarStatusValidacao } from '../data/baseMedicamentosInfo';
import { billingConfig } from '../data/billingConfig';
import { medicamentos, totalMedicamentosEnriquecidos } from '../data/medicamentos';
import { premiumPlans } from '../data/premium';
import { ScreenName, tabFromScreen } from '../navigation';
import { PremiumState, PremiumStatus } from '../storage/premium';
import { theme } from '../styles/theme';

const DEV_PIN = '274798';

type Props = {
  onNavigate: (screen: ScreenName) => void;
  activeScreen: ScreenName;
  premium: PremiumState;
  premiumStatus: PremiumStatus;
  totalRegistros: number;
  onAtivarDev: () => Promise<void>;
  onDesativarPremium: () => Promise<void>;
  onZerarConsultas: () => Promise<void>;
  onExportarDados: () => Promise<void>;
  onLimparDados: () => Promise<void>;
};

export function DevScreen({ onNavigate, activeScreen, premium, premiumStatus, totalRegistros, onAtivarDev, onDesativarPremium, onZerarConsultas, onExportarDados, onLimparDados }: Props) {
  const [pin, setPin] = useState('');
  const [liberado, setLiberado] = useState(false);
  const statusBase = contarStatusValidacao(medicamentos);

  function validarPin() {
    if (pin.trim() === DEV_PIN) {
      setLiberado(true);
      setPin('');
      return;
    }
    Alert.alert('PIN incorreto', 'Acesso negado à Área Admin.');
  }

  async function ativarDev() {
    await onAtivarDev();
    Alert.alert('Pro liberado', 'O acesso Pro/Dev foi liberado localmente neste aparelho.');
  }

  async function removerPro() {
    await onDesativarPremium();
    Alert.alert('Liberação removida', 'O acesso Pro local foi desativado neste aparelho.');
  }

  async function zerarConsultas() {
    await onZerarConsultas();
    Alert.alert('Consultas zeradas', 'O contador gratuito foi reiniciado neste aparelho.');
  }

  function confirmarLimpezaLocal() {
    Alert.alert(
      'Limpar dados locais?',
      'Tem certeza? Esta ação não pode ser desfeita. Os registros locais de atendimento serão apagados deste aparelho.',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Limpar dados', style: 'destructive', onPress: async () => { await onLimparDados(); Alert.alert('Dados limpos', 'Registros locais apagados.'); } },
      ]
    );
  }

  if (!liberado) {
    return (
      <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
        <Title>Área Admin</Title>
        <Muted>Área restrita para ajustes internos, liberação local e diagnóstico comercial.</Muted>

        <Card>
          <Subtitle>Digite o PIN do administrador</Subtitle>
          <TextInput
            value={pin}
            onChangeText={setPin}
            placeholder="PIN de 6 dígitos"
            placeholderTextColor={theme.colors.muted}
            keyboardType="number-pad"
            secureTextEntry
            style={styles.input}
            maxLength={8}
          />
          <PrimaryButton title="Entrar" onPress={validarPin} variant="primary" />
          <PrimaryButton title="Voltar" onPress={() => onNavigate('mais')} variant="secondary" />
        </Card>
      </Screen>
    );
  }

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <Title>Área Admin</Title>
      <Muted>Ajustes locais, diagnóstico, liberação Pro e preparação para App Store / Play Store.</Muted>

      <Card>
        <Subtitle>Diagnóstico do aplicativo</Subtitle>
        <InfoRow label="Versão" value={appInfo.versao} />
        <InfoRow label="Ambiente" value="demonstração comercial" />
        <InfoRow label="Modo Pro" value={premiumStatus.ativo ? 'ativo' : 'inativo'} />
        <InfoRow label="Base local" value={`${medicamentos.length} medicamentos`} />
        <InfoRow label="Registros locais" value={`${totalRegistros}`} />
        <InfoRow label="Dados locais" value="ativo / somente neste aparelho" />
      </Card>

      <Card>
        <Subtitle>Status comercial</Subtitle>
        <Body>{premiumStatus.ativo ? '✅ Acesso Pro ativo neste aparelho.' : '🔒 Acesso Pro inativo neste aparelho.'}</Body>
        <InfoRow label="Plano" value={premium.plano || 'nenhum'} />
        <InfoRow label="Código" value={premium.codigoUsado || 'nenhum'} />
        <InfoRow label="Consultas grátis usadas" value={`${premiumStatus.consultasUsadas}/${premiumStatus.limiteGratis}`} />
        <View style={styles.buttonGroup}>
          <PrimaryButton title="Liberar Pro neste aparelho" onPress={ativarDev} variant="success" />
          <PrimaryButton title="Revogar Pro neste aparelho" onPress={removerPro} variant="danger" />
          <PrimaryButton title="Zerar consultas grátis" onPress={zerarConsultas} variant="secondary" />
        </View>
        <Muted>Liberação manual apenas para teste e demonstração. A venda real será conectada depois via Apple/Google Billing.</Muted>
      </Card>

      <Card>
        <Subtitle>Base de medicamentos</Subtitle>
        <InfoRow label="Total" value={`${medicamentos.length}`} />
        <InfoRow label="Enriquecidos" value={`${totalMedicamentosEnriquecidos}`} />
        <InfoRow label="Validados" value={`${statusBase.validado}`} />
        <InfoRow label="Pré-validados" value={`${statusBase.pre_validado}`} />
        <InfoRow label="Parciais" value={`${statusBase.parcial}`} />
        <InfoRow label="Pendentes" value={`${statusBase.pendente}`} />
        <InfoRow label="Última atualização" value={appInfo.ultimaAtualizacaoBase} />
      </Card>

      <Card>
        <Subtitle>Dados locais</Subtitle>
        <Body>Exportação em JSON e limpeza local dos registros do aparelho.</Body>
        <PrimaryButton title="Exportar dados" onPress={onExportarDados} variant="primary" />
        <PrimaryButton title="Limpar dados locais" onPress={confirmarLimpezaLocal} variant="danger" />
      </Card>

      <Card>
        <Subtitle>Produtos de loja preparados</Subtitle>
        <InfoRow label="Entitlement" value={billingConfig.entitlementId} />
        <InfoRow label="Offering" value={billingConfig.offeringId} />
        {premiumPlans.map((plano) => (
          <View key={plano.id} style={styles.productBox}>
            <Text style={styles.productName}>{plano.nome}</Text>
            <Text style={styles.productId}>{plano.productId}</Text>
            <Text style={styles.productMeta}>{plano.tipoLoja === 'assinatura' ? 'Assinatura' : 'Compra única'} · {plano.recorrencia}</Text>
          </View>
        ))}
      </Card>

      <Card>
        <Subtitle>Próxima etapa real de cobrança</Subtitle>
        <Body>Quando Apple Developer, App Store Connect, Google Play Console e RevenueCat estiverem configurados, substitua as chaves públicas em src/data/billingConfig.ts e conecte o SDK RevenueCat.</Body>
        <Muted>Não coloque segredo, token privado, senha ou chave de API sensível dentro do app.</Muted>
      </Card>

      <PrimaryButton title="Voltar para Mais" onPress={() => onNavigate('mais')} variant="secondary" />
    </Screen>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.row}>
      <Text style={styles.rowLabel}>{label}</Text>
      <Text style={styles.rowValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  input: { backgroundColor: theme.colors.card2, color: theme.colors.text, borderWidth: 1, borderColor: theme.colors.border, borderRadius: theme.radius.md, padding: 14, marginVertical: 10 },
  buttonGroup: { marginTop: 10 },
  row: { flexDirection: 'row', justifyContent: 'space-between', gap: 10, borderBottomWidth: 1, borderBottomColor: theme.colors.border, paddingVertical: 8 },
  rowLabel: { color: theme.colors.muted, flex: 1, fontWeight: '700' },
  rowValue: { color: theme.colors.text, flex: 1.4, textAlign: 'right' },
  productBox: { backgroundColor: theme.colors.card2, borderRadius: theme.radius.md, borderWidth: 1, borderColor: theme.colors.border, padding: 10, marginTop: 8 },
  productName: { color: theme.colors.text, fontWeight: '900', marginBottom: 3 },
  productId: { color: theme.colors.primary, fontWeight: '800' },
  productMeta: { color: theme.colors.muted, fontSize: 12, marginTop: 3 },
});
