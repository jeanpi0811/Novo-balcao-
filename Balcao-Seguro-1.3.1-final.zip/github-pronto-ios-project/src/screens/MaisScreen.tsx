import React from 'react';
import { Alert, Linking, StyleSheet, Text, View } from 'react-native';
import { ActionTile } from '../components/ActionTile';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { appInfo } from '../data/appInfo';
import { premiumConfig } from '../data/premium';
import { ScreenName, tabFromScreen } from '../navigation';
import { PremiumStatus } from '../storage/premium';
import { theme } from '../styles/theme';

type Props = {
  onNavigate: (screen: ScreenName) => void;
  totalRegistros: number;
  activeScreen: ScreenName;
  onExportarDados: () => Promise<void>;
  onLimparDados: () => Promise<void>;
  premiumStatus: PremiumStatus;
};

export function MaisScreen({ onNavigate, totalRegistros, activeScreen, onExportarDados, onLimparDados, premiumStatus }: Props) {
  async function abrirSuporte() {
    await Linking.openURL(premiumConfig.suporteWhatsAppUrl);
  }

  function confirmarLimpeza() {
    Alert.alert(
      'Limpar dados locais?',
      'Tem certeza? Esta ação não pode ser desfeita. Os registros locais de atendimento serão apagados deste aparelho.',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Limpar dados',
          style: 'destructive',
          onPress: async () => {
            await onLimparDados();
            Alert.alert('Dados locais limpos', 'Os registros locais foram removidos deste aparelho.');
          },
        },
      ]
    );
  }

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <Title>Mais</Title>
      <Muted>Administração, informações comerciais, dados locais e sistema.</Muted>

      <SectionTitle>Administração do aplicativo</SectionTitle>
      <Card>
        <View style={styles.adminHeader}>
          <Text style={styles.adminIcon}>🛠️</Text>
          <View style={styles.adminTitleWrap}>
            <Subtitle>Área Admin</Subtitle>
            <Muted>Acesso restrito por PIN para liberação Pro local, diagnóstico e ajustes de demonstração.</Muted>
          </View>
        </View>
        <Body>Status atual: {premiumStatus.ativo ? 'Pro ativo neste aparelho' : 'Pro inativo neste aparelho'}.</Body>
        <PrimaryButton title="Entrar na Área Admin" onPress={() => onNavigate('dev')} variant="secondary" />
      </Card>

      <SectionTitle>Informações do aplicativo</SectionTitle>
      <ActionTile icon="ℹ️" title="Sobre o Balcão Seguro" body="Finalidade, responsável profissional, versão e escopo de uso." onPress={() => onNavigate('sobre')} tone="muted" />
      <ActionTile icon="📚" title="Base de medicamentos" body="Versão da base, total de medicamentos, status de validação e fontes." onPress={() => onNavigate('fontes')} tone="muted" />
      <ActionTile icon="📄" title="Termos de uso" body="Avisos de responsabilidade e limites do aplicativo." onPress={() => onNavigate('termos')} tone="muted" />
      <ActionTile icon="🔒" title="Política de privacidade" body="Dados locais, ausência de servidor e cuidados antes de publicação." onPress={() => onNavigate('privacidade')} tone="muted" />
      <ActionTile icon="💬" title="Suporte" body={appInfo.contatoSuporte} onPress={abrirSuporte} tone="green" />

      <SectionTitle>Dados locais</SectionTitle>
      <ActionTile icon="📤" title="Exportar dados" body={premiumStatus.ativo ? `Gerar JSON de exportação com ${totalRegistros} registro(s) local(is).` : 'Recurso Pro: exportação JSON dos registros locais.'} onPress={premiumStatus.ativo ? onExportarDados : () => onNavigate('premium')} tone="primary" />
      <ActionTile icon="🧹" title="Limpar dados locais" body="Apagar registros locais deste aparelho com confirmação forte." onPress={confirmarLimpeza} tone="red" />

      <SectionTitle>Sistema</SectionTitle>
      <Card>
        <Subtitle>Versão do app</Subtitle>
        <InfoRow label="Versão" value={appInfo.versao} />
        <InfoRow label="Ambiente" value="Demonstração comercial" />
        <InfoRow label="Modo Pro" value={premiumStatus.ativo ? 'ativo localmente' : 'preparado / inativo'} />
      </Card>
      <Card>
        <Subtitle>Status da base local</Subtitle>
        <Body>{appInfo.bancoMedicamentos}</Body>
        <Muted>Última atualização: {appInfo.ultimaAtualizacaoBase}</Muted>
      </Card>

      <ActionTile icon="💎" title="Balcão Seguro Pro" body="Planos Mensal, Anual e Vitalício preparados para Apple/Google Billing." onPress={() => onNavigate('premium')} tone="yellow" />
    </Screen>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return <Text style={styles.sectionTitle}>{children}</Text>;
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.metaRow}>
      <Text style={styles.metaLabel}>{label}</Text>
      <Text style={styles.metaValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  sectionTitle: { color: theme.colors.primary, fontWeight: '900', fontSize: 14, marginTop: 8, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.6 },
  adminHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 6 },
  adminIcon: { fontSize: 26 },
  adminTitleWrap: { flex: 1 },
  metaRow: { flexDirection: 'row', gap: 10, justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: theme.colors.border, paddingVertical: 8 },
  metaLabel: { color: theme.colors.muted, fontWeight: '700', flex: 1 },
  metaValue: { color: theme.colors.text, flex: 2, textAlign: 'right' }
});
