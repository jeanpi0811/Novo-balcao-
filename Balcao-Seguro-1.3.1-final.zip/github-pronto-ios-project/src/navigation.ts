export type ScreenName =
  | 'home'
  | 'atendimento'
  | 'triagem'
  | 'medicamentos'
  | 'interacoes'
  | 'troca'
  | 'registro'
  | 'mais'
  | 'sobre'
  | 'termos'
  | 'privacidade'
  | 'fontes'
  | 'premium'
  | 'dev';

export type AppTab = 'home' | 'atendimento' | 'medicamentos' | 'interacoes' | 'mais';

export function tabFromScreen(screen: ScreenName): AppTab {
  if (screen === 'atendimento' || screen === 'triagem' || screen === 'registro') return 'atendimento';
  if (screen === 'medicamentos' || screen === 'troca') return 'medicamentos';
  if (screen === 'interacoes') return 'interacoes';
  if (screen === 'mais' || screen === 'sobre' || screen === 'termos' || screen === 'privacidade' || screen === 'fontes' || screen === 'dev' || screen === 'premium') return 'mais';
  return 'home';
}
