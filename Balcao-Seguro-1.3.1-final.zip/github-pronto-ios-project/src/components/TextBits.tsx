import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { theme } from '../styles/theme';

export function Title({ children }: { children: React.ReactNode }) {
  return <Text style={styles.title}>{children}</Text>;
}

export function Subtitle({ children }: { children: React.ReactNode }) {
  return <Text style={styles.subtitle}>{children}</Text>;
}

export function Body({ children }: { children: React.ReactNode }) {
  return <Text style={styles.body}>{children}</Text>;
}

export function Muted({ children }: { children: React.ReactNode }) {
  return <Text style={styles.muted}>{children}</Text>;
}

const styles = StyleSheet.create({
  title: { color: theme.colors.text, fontSize: 28, fontWeight: '800', marginBottom: 8 },
  subtitle: { color: theme.colors.text, fontSize: 18, fontWeight: '700', marginBottom: 8 },
  body: { color: theme.colors.text, fontSize: 15, lineHeight: 22 },
  muted: { color: theme.colors.muted, fontSize: 13, lineHeight: 20 }
});
