import React from 'react';
import { Pressable, Text, StyleSheet, ViewStyle } from 'react-native';
import { theme } from '../styles/theme';

type Props = {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'danger' | 'success';
  style?: ViewStyle;
};

export function PrimaryButton({ title, onPress, variant = 'primary', style }: Props) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.button, styles[variant], pressed && styles.pressed, style]}>
      <Text style={styles.text}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: theme.radius.md,
    alignItems: 'center',
    marginVertical: 5
  },
  primary: { backgroundColor: theme.colors.primary },
  secondary: { backgroundColor: theme.colors.card2, borderWidth: 1, borderColor: theme.colors.border },
  danger: { backgroundColor: theme.colors.red },
  success: { backgroundColor: theme.colors.green },
  pressed: { opacity: 0.75 },
  text: { color: theme.colors.white, fontWeight: '700', fontSize: 15 }
});
