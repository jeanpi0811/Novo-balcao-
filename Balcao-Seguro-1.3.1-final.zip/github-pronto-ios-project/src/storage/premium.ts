import AsyncStorage from '@react-native-async-storage/async-storage';

export const LIMITE_CONSULTAS_GRATIS = 3;
const STORAGE_KEY = '@balcao_seguro:premium_v121';

export type PlanoPremiumAtivo = 'mensal' | 'anual' | 'vitalicio' | 'manual' | 'dev';

export type PremiumState = {
  ativo: boolean;
  plano?: PlanoPremiumAtivo;
  ativoDesde?: string;
  validadeISO?: string;
  codigoUsado?: string;
  consultasUsadas: number;
};

export type PremiumStatus = {
  ativo: boolean;
  plano?: PlanoPremiumAtivo;
  consultasUsadas: number;
  limiteGratis: number;
  consultasRestantes: number;
};

const codigosLocais: Record<string, PlanoPremiumAtivo> = {
  'BALCAO-PREMIUM-2026': 'vitalicio',
  'JEAN-CRF-15974': 'vitalicio',
  'BALCAO-VITALICIO-4990': 'vitalicio',
  '274798': 'dev',
};

function estadoPadrao(): PremiumState {
  return { ativo: false, consultasUsadas: 0 };
}

export function premiumEstaAtivo(estado: PremiumState): boolean {
  if (!estado.ativo) return false;
  if (!estado.validadeISO) return true;
  return new Date(estado.validadeISO).getTime() > Date.now();
}

export function statusPremium(estado: PremiumState): PremiumStatus {
  const ativo = premiumEstaAtivo(estado);
  const restantes = Math.max(0, LIMITE_CONSULTAS_GRATIS - (estado.consultasUsadas || 0));
  return {
    ativo,
    plano: estado.plano,
    consultasUsadas: estado.consultasUsadas || 0,
    limiteGratis: LIMITE_CONSULTAS_GRATIS,
    consultasRestantes: ativo ? 999999 : restantes,
  };
}

export async function carregarPremium(): Promise<PremiumState> {
  try {
    const bruto = await AsyncStorage.getItem(STORAGE_KEY);
    if (!bruto) return estadoPadrao();
    const parsed = JSON.parse(bruto) as PremiumState;
    return { ...estadoPadrao(), ...parsed, consultasUsadas: Number(parsed.consultasUsadas || 0) };
  } catch {
    return estadoPadrao();
  }
}

export async function salvarPremium(estado: PremiumState): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(estado));
}

export async function ativarPremiumPorCodigo(codigo: string, estadoAtual: PremiumState): Promise<{ ok: boolean; estado: PremiumState; mensagem: string }> {
  const normalizado = codigo.trim().toUpperCase().replace(/\s+/g, '');
  const plano = codigosLocais[normalizado];
  if (!plano) {
    return { ok: false, estado: estadoAtual, mensagem: 'Código não reconhecido. Confira maiúsculas, hífens e o código recebido após o pagamento.' };
  }

  const novo: PremiumState = {
    ...estadoAtual,
    ativo: true,
    plano,
    ativoDesde: new Date().toISOString(),
    validadeISO: plano === 'mensal' ? new Date(Date.now() + 31 * 24 * 60 * 60 * 1000).toISOString() : undefined,
    codigoUsado: normalizado,
  };
  await salvarPremium(novo);
  return { ok: true, estado: novo, mensagem: 'Premium ativado neste aparelho.' };
}

export async function registrarConsultaCompleta(estadoAtual: PremiumState): Promise<{ permitido: boolean; estado: PremiumState }> {
  if (premiumEstaAtivo(estadoAtual)) return { permitido: true, estado: estadoAtual };
  const usadas = estadoAtual.consultasUsadas || 0;
  if (usadas >= LIMITE_CONSULTAS_GRATIS) return { permitido: false, estado: estadoAtual };
  const novo = { ...estadoAtual, consultasUsadas: usadas + 1 };
  await salvarPremium(novo);
  return { permitido: true, estado: novo };
}


export async function ativarPremiumDev(estadoAtual: PremiumState): Promise<PremiumState> {
  const novo: PremiumState = {
    ...estadoAtual,
    ativo: true,
    plano: 'dev',
    ativoDesde: new Date().toISOString(),
    validadeISO: undefined,
    codigoUsado: 'DEV-LOCAL-274798',
  };
  await salvarPremium(novo);
  return novo;
}

export async function desativarPremiumLocal(estadoAtual: PremiumState): Promise<PremiumState> {
  const novo: PremiumState = {
    ...estadoAtual,
    ativo: false,
    plano: undefined,
    validadeISO: undefined,
    codigoUsado: undefined,
  };
  await salvarPremium(novo);
  return novo;
}

export async function zerarConsultasGratis(estadoAtual: PremiumState): Promise<PremiumState> {
  const novo: PremiumState = { ...estadoAtual, consultasUsadas: 0 };
  await salvarPremium(novo);
  return novo;
}
