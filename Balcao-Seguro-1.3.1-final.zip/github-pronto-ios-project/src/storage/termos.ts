import AsyncStorage from '@react-native-async-storage/async-storage';

export const VERSAO_TERMOS_ACEITE = '2026-06-25-v1-termos-responsabilidade';

export type AceiteTermos = {
  aceito: boolean;
  versao: string;
  aceitoEm: string;
};

const STORAGE_KEY = '@balcao_seguro:aceite_termos_responsabilidade';

export async function carregarAceiteTermos(): Promise<AceiteTermos | null> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AceiteTermos;
    if (parsed?.aceito === true && parsed?.versao === VERSAO_TERMOS_ACEITE) return parsed;
    return null;
  } catch {
    return null;
  }
}

export async function salvarAceiteTermos(): Promise<AceiteTermos> {
  const aceite: AceiteTermos = {
    aceito: true,
    versao: VERSAO_TERMOS_ACEITE,
    aceitoEm: new Date().toISOString()
  };
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(aceite));
  return aceite;
}

export async function limparAceiteTermos(): Promise<void> {
  await AsyncStorage.removeItem(STORAGE_KEY);
}
