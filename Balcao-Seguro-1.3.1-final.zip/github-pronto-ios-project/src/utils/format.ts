import { Gravidade } from '../types';

export function gravidadeEmoji(gravidade: Gravidade) {
  if (gravidade === 'vermelho') return '🔴';
  if (gravidade === 'amarelo') return '🟡';
  return '🟢';
}

export function formatarData(dataISO: string) {
  const data = new Date(dataISO);
  if (Number.isNaN(data.getTime())) return 'Data inválida';
  return data.toLocaleString('pt-BR');
}
