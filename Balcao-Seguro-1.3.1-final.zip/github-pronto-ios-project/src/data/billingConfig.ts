export const billingConfig = {
  modo: 'apple_google_revenuecat_preparado',
  entitlementId: 'pro',
  offeringId: 'default',
  revenueCatIosPublicKey: 'PREENCHER_REVENUECAT_IOS_PUBLIC_SDK_KEY',
  revenueCatAndroidPublicKey: 'PREENCHER_REVENUECAT_ANDROID_PUBLIC_SDK_KEY',
  observacao: 'Pagamentos de recursos digitais devem usar Apple In-App Purchase no iOS e Google Play Billing no Android. RevenueCat é a camada recomendada para unificar as duas lojas.',
  produtos: {
    mensal: 'balcao_pro_mensal',
    anual: 'balcao_pro_anual',
    vitalicio: 'balcao_pro_vitalicio',
  },
};
