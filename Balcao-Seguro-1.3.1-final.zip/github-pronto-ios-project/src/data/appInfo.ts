export const appInfo = {
  nome: 'Balcão Seguro',
  slogan: 'Ferramenta de apoio ao atendimento farmacêutico, com consulta local, organização de dados e preparação comercial Grátis/Pro.',
  versao: '1.3.0-reconstrucao-busca-estavel',
  pacote: 'br.com.farmabolso.balcaoseguro',
  contatoSuporte: 'WhatsApp (54) 99142-7519',
  responsavelFarmaceutico: 'Jean Pierre Andres',
  registroProfissional: 'CRF/RS 15974',
  responsabilidade: 'Responsável pelo conteúdo farmacêutico e curadoria inicial do app. O app é ferramenta de apoio informativo: não realiza diagnóstico, não prescreve e não substitui responsabilidade técnica, protocolos locais, bula ou avaliação presencial quando necessária.',
  bancoMedicamentos: 'Base local offline com 5200 medicamentos/substâncias/termos de busca farmacêuticos para triagem, grupos especiais, interações, efeitos adversos, resumo leigo, fontes e pendências de validação. Itens não substituem bula profissional do produto específico.',
  ultimaAtualizacaoBase: '2026-09-11 — v1.3.0: tela compacta de resultados, busca estável, teclado ajustado e consulta sem bloqueio Premium.',
  coletaDados: 'Não envia dados para servidores. Registros ficam salvos somente no aparelho, salvo exportação/compartilhamento manual pelo usuário.',
  publicoAlvo: 'Uso de apoio por profissional habilitado no atendimento farmacêutico.',
};
