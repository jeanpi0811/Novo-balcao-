import { ProtocoloTriagem } from '../types';

export const protocolos: ProtocoloTriagem[] = [
  {
    id: 'dor-garganta',
    titulo: 'Dor de garganta',
    categoria: 'Respiratório',
    resumo: 'Triagem rápida para dor de garganta, rouquidão e irritação faríngea.',
    perguntas: [
      { id: 'falta-ar', texto: 'Tem falta de ar, chiado intenso ou dificuldade para engolir saliva?', gravidade: 'vermelho', motivo: 'Pode indicar quadro grave ou obstrução/infecção importante.' },
      { id: 'febre-alta', texto: 'Febre alta persistente ou piora importante do estado geral?', gravidade: 'vermelho', motivo: 'Sinal de alerta para avaliação médica.' },
      { id: 'crianca-pequena', texto: 'Paciente é criança pequena, gestante, idoso frágil ou imunossuprimido?', gravidade: 'amarelo', motivo: 'Grupo que exige avaliação mais cautelosa.' },
      { id: 'placas-pus', texto: 'Há placas, pus, dor intensa unilateral ou ínguas dolorosas?', gravidade: 'amarelo', motivo: 'Pode precisar avaliação clínica para diferenciar causas.' }
    ],
    orientacaoVerde: ['Orientar hidratação, repouso vocal, evitar fumaça/álcool e monitorar evolução.', 'MIP sintomático pode ser considerado conforme perfil do paciente.'],
    orientacaoAmarela: ['Fazer avaliação farmacêutica mais completa antes de indicar.', 'Checar alergias, idade, gestação, comorbidades e medicamentos em uso.'],
    condutaVermelha: ['Não tratar apenas como dor simples.', 'Orientar atendimento médico/urgência conforme intensidade dos sinais.'],
    mipPossiveis: ['Pastilha sem anestésico forte', 'Analgésico/antitérmico conforme perfil', 'Solução salina/gargarejo sem risco'],
    evitar: ['Antibiótico sem prescrição', 'Anti-inflamatório em paciente de risco sem avaliação', 'Corticosteroide por conta própria']
  },
  {
    id: 'tosse',
    titulo: 'Tosse',
    categoria: 'Respiratório',
    resumo: 'Triagem de tosse seca/produtiva e sinais de alerta.',
    perguntas: [
      { id: 'falta-ar', texto: 'Tem falta de ar, lábios roxos, dor no peito ou chiado importante?', gravidade: 'vermelho', motivo: 'Pode indicar gravidade respiratória.' },
      { id: 'sangue', texto: 'Sai sangue ao tossir?', gravidade: 'vermelho', motivo: 'Hemoptise exige avaliação médica.' },
      { id: 'tempo', texto: 'Tosse dura mais de 3 semanas ou vem piorando?', gravidade: 'amarelo', motivo: 'Tosse persistente precisa investigação.' },
      { id: 'asma-dpoc', texto: 'Paciente tem asma, DPOC, cardiopatia, gestação ou é criança pequena?', gravidade: 'amarelo', motivo: 'Comorbidades mudam conduta.' }
    ],
    orientacaoVerde: ['Orientar hidratação, evitar irritantes e avaliar se é tosse seca ou produtiva.', 'Não suprimir tosse produtiva sem necessidade.'],
    orientacaoAmarela: ['Verificar medicamentos em uso, especialmente IECA, antialérgicos e sedativos.', 'Considerar encaminhamento se houver persistência ou comorbidade.'],
    condutaVermelha: ['Encaminhar para atendimento médico/urgência.', 'Não mascarar sintoma grave com antitussivo.'],
    mipPossiveis: ['Mel/hidratação para adultos sem contraindicação', 'Lavagem nasal', 'Expectorante ou antitussivo apenas conforme tipo de tosse e perfil'],
    evitar: ['Antitussivo sedativo em idoso sem avaliação', 'Associação de múltiplos xaropes', 'Uso em crianças pequenas sem orientação profissional']
  },
  {
    id: 'febre',
    titulo: 'Febre',
    categoria: 'Geral',
    resumo: 'Triagem para febre e identificação de sinais de urgência.',
    perguntas: [
      { id: 'rigidez', texto: 'Tem rigidez na nuca, confusão, convulsão, manchas roxas ou sonolência extrema?', gravidade: 'vermelho', motivo: 'Sinais de urgência.' },
      { id: 'bebe', texto: 'É bebê pequeno, gestante, idoso frágil ou imunossuprimido?', gravidade: 'vermelho', motivo: 'Grupo de alto risco.' },
      { id: 'persistente', texto: 'Febre persiste por mais de 72 horas?', gravidade: 'amarelo', motivo: 'Pode precisar avaliação médica.' },
      { id: 'dor-local', texto: 'Há dor intensa localizada, falta de ar, vômitos persistentes ou desidratação?', gravidade: 'amarelo', motivo: 'Sinais associados podem indicar gravidade.' }
    ],
    orientacaoVerde: ['Orientar hidratação, repouso e medidas físicas leves.', 'Antitérmico pode ser considerado conforme perfil.'],
    orientacaoAmarela: ['Investigar sintomas associados e medicamentos em uso.', 'Orientar retorno/encaminhamento se persistir ou piorar.'],
    condutaVermelha: ['Encaminhar para avaliação médica/urgência.', 'Não atrasar atendimento tentando apenas baixar febre.'],
    mipPossiveis: ['Paracetamol conforme dose segura', 'Dipirona conforme perfil e histórico', 'Hidratação oral'],
    evitar: ['Associação duplicada de antitérmicos sem controle', 'AAS em criança/adolescente', 'Dose acima do limite diário']
  },
  {
    id: 'diarreia',
    titulo: 'Diarreia',
    categoria: 'Gastrointestinal',
    resumo: 'Triagem para diarreia aguda e risco de desidratação.',
    perguntas: [
      { id: 'sangue', texto: 'Há sangue nas fezes, febre alta ou dor abdominal intensa?', gravidade: 'vermelho', motivo: 'Pode indicar infecção invasiva ou abdome agudo.' },
      { id: 'desidratacao', texto: 'Sinais de desidratação: boca seca, tontura, pouca urina, sonolência?', gravidade: 'vermelho', motivo: 'Desidratação pode ser grave.' },
      { id: 'risco', texto: 'Paciente é criança pequena, idoso, gestante ou imunossuprimido?', gravidade: 'amarelo', motivo: 'Maior risco de complicações.' },
      { id: 'tempo', texto: 'Dura mais de 48-72 horas ou houve viagem/alimento suspeito?', gravidade: 'amarelo', motivo: 'Pode precisar investigação.' }
    ],
    orientacaoVerde: ['Priorizar reidratação oral e alimentação leve.', 'Orientar sinais de alerta e retorno se piorar.'],
    orientacaoAmarela: ['Avaliar risco individual e necessidade de encaminhar.', 'Evitar mascarar quadro infeccioso.'],
    condutaVermelha: ['Encaminhar para atendimento médico/urgência.', 'Reidratação é prioridade.'],
    mipPossiveis: ['Soro de reidratação oral', 'Probiótico conforme caso', 'Simeticona se gases associados'],
    evitar: ['Antidiarreico com sangue/febre', 'Antibiótico sem prescrição', 'Anti-inflamatório em desidratação']
  },
  {
    id: 'azia',
    titulo: 'Azia/Refluxo',
    categoria: 'Gastrointestinal',
    resumo: 'Triagem de queimação, refluxo e dispepsia.',
    perguntas: [
      { id: 'dor-peito', texto: 'Dor no peito, falta de ar, suor frio ou dor irradiando para braço/mandíbula?', gravidade: 'vermelho', motivo: 'Pode simular evento cardíaco.' },
      { id: 'sangramento', texto: 'Vômito com sangue, fezes pretas ou perda de peso inexplicada?', gravidade: 'vermelho', motivo: 'Sinais de alarme gastrointestinal.' },
      { id: 'persistente', texto: 'Sintomas frequentes por mais de 2 semanas?', gravidade: 'amarelo', motivo: 'Pode precisar investigação e tratamento estruturado.' },
      { id: 'medicamentos', texto: 'Usa anti-inflamatório, AAS, anticoagulante ou corticoide?', gravidade: 'amarelo', motivo: 'Maior risco gastrointestinal.' }
    ],
    orientacaoVerde: ['Orientar evitar refeição pesada à noite, álcool, cigarro e deitar após comer.', 'MIP pode ser usado por curto período conforme perfil.'],
    orientacaoAmarela: ['Avaliar medicamentos causadores e risco de sangramento.', 'Encaminhar se recorrente.'],
    condutaVermelha: ['Encaminhar para atendimento médico/urgência.', 'Não tratar dor torácica como azia sem avaliação.'],
    mipPossiveis: ['Antiácido', 'Alginate', 'Bloqueador H2/IBP por curto período conforme perfil'],
    evitar: ['Uso prolongado sem avaliação', 'Mascarar sinais de sangramento', 'Anti-inflamatório para dor gástrica']
  },
  {
    id: 'dor-muscular',
    titulo: 'Dor muscular/articular',
    categoria: 'Dor',
    resumo: 'Triagem para dor muscular, lombalgia leve e esforço físico.',
    perguntas: [
      { id: 'trauma', texto: 'Houve queda, trauma forte, deformidade ou incapacidade de movimentar?', gravidade: 'vermelho', motivo: 'Pode exigir exame/imagem.' },
      { id: 'neurologico', texto: 'Fraqueza, perda de sensibilidade, perda urinária/fecal ou dor irradiada intensa?', gravidade: 'vermelho', motivo: 'Sinal neurológico de alerta.' },
      { id: 'risco-ai', texto: 'Tem doença renal, gastrite/úlcera, hipertensão, usa anticoagulante ou é idoso?', gravidade: 'amarelo', motivo: 'Anti-inflamatórios podem ter risco aumentado.' },
      { id: 'persistente', texto: 'Dor dura mais de 7 dias ou piora progressivamente?', gravidade: 'amarelo', motivo: 'Pode precisar avaliação clínica.' }
    ],
    orientacaoVerde: ['Orientar repouso relativo, calor/frio local conforme caso e alongamento leve.', 'Analgésico tópico/oral pode ser considerado conforme perfil.'],
    orientacaoAmarela: ['Evitar anti-inflamatório sem avaliar riscos.', 'Considerar encaminhamento se persistente.'],
    condutaVermelha: ['Encaminhar para atendimento médico/urgência.', 'Não atrasar avaliação se houver sinal neurológico.'],
    mipPossiveis: ['Analgésico simples', 'Gel tópico', 'Compressa/medidas físicas'],
    evitar: ['Anti-inflamatório em paciente de risco', 'Relaxante sedativo sem avaliação', 'Combinar múltiplos analgésicos']
  },
  {
    id: 'alergia-rinite',
    titulo: 'Alergia/Rinite',
    categoria: 'Alergia',
    resumo: 'Triagem para rinite, coceira, espirros e alergias leves.',
    perguntas: [
      { id: 'anafilaxia', texto: 'Inchaço em lábios/língua, falta de ar, chiado ou sensação de desmaio?', gravidade: 'vermelho', motivo: 'Pode indicar reação alérgica grave.' },
      { id: 'urticaria-grave', texto: 'Urticária extensa com piora rápida?', gravidade: 'vermelho', motivo: 'Risco de evolução grave.' },
      { id: 'crianca-idoso', texto: 'Paciente é criança pequena, idoso frágil, gestante ou usa sedativos?', gravidade: 'amarelo', motivo: 'Antialérgicos podem causar sedação e outros riscos.' },
      { id: 'persistente', texto: 'Sintomas são persistentes ou atrapalham sono/trabalho?', gravidade: 'amarelo', motivo: 'Pode precisar manejo contínuo. ' }
    ],
    orientacaoVerde: ['Orientar higiene nasal, evitar gatilhos e lavar roupas/ambiente.', 'Antialérgico não sedativo pode ser considerado conforme perfil.'],
    orientacaoAmarela: ['Avaliar risco de sedação, glaucoma, próstata aumentada e interações.', 'Encaminhar se persistente.'],
    condutaVermelha: ['Encaminhar imediatamente para urgência.', 'Não tentar resolver anafilaxia no balcão.'],
    mipPossiveis: ['Soro nasal', 'Antihistamínico não sedativo conforme perfil', 'Lubrificante ocular se irritação leve'],
    evitar: ['Antialérgico sedativo em motorista/idoso', 'Descongestionante sistêmico em hipertenso', 'Corticoide sem orientação']
  },
  {
    id: 'dor-urinaria',
    titulo: 'Dor urinária',
    categoria: 'Urinário',
    resumo: 'Triagem para ardência ao urinar, urgência urinária e sinais de infecção.',
    perguntas: [
      { id: 'febre-lombar', texto: 'Tem febre, dor lombar, calafrios, náusea/vômitos?', gravidade: 'vermelho', motivo: 'Pode indicar infecção urinária alta.' },
      { id: 'gestante-homem', texto: 'Paciente é gestante, homem, criança ou idoso frágil?', gravidade: 'vermelho', motivo: 'Requer avaliação médica. ' },
      { id: 'sangue', texto: 'Há sangue na urina ou dor intensa?', gravidade: 'amarelo', motivo: 'Precisa avaliação mais cuidadosa.' },
      { id: 'recorrente', texto: 'É recorrente ou já usou antibiótico recentemente?', gravidade: 'amarelo', motivo: 'Pode haver resistência ou diagnóstico diferente.' }
    ],
    orientacaoVerde: ['Orientar hidratação e procurar avaliação se piorar.', 'Não indicar antibiótico sem prescrição.'],
    orientacaoAmarela: ['Orientar avaliação médica/farmacêutica detalhada conforme protocolos locais.', 'Checar gestação e sinais sistêmicos.'],
    condutaVermelha: ['Encaminhar para atendimento médico.', 'Não atrasar tratamento em suspeita de pielonefrite/risco.'],
    mipPossiveis: ['Hidratação', 'Analgésico simples conforme perfil', 'Orientações comportamentais'],
    evitar: ['Antibiótico sem prescrição', 'Mascarar febre/dor lombar', 'Anti-inflamatório em renal/desidratado']
  },
  {
    id: 'constipacao',
    titulo: 'Constipação',
    categoria: 'Gastrointestinal',
    resumo: 'Triagem para prisão de ventre e sinais de alerta.',
    perguntas: [
      { id: 'obstrucao', texto: 'Dor abdominal forte, vômitos, barriga muito distendida ou não elimina gases?', gravidade: 'vermelho', motivo: 'Pode sugerir obstrução ou quadro agudo.' },
      { id: 'sangue-peso', texto: 'Sangue nas fezes, perda de peso ou anemia conhecida?', gravidade: 'vermelho', motivo: 'Sinal de alarme.' },
      { id: 'novo-idoso', texto: 'Constipação nova em idoso ou mudança brusca do hábito intestinal?', gravidade: 'amarelo', motivo: 'Precisa avaliação.' },
      { id: 'medicamentos', texto: 'Usa opioide, ferro, antidepressivo, antiácido com alumínio ou anticolinérgico?', gravidade: 'amarelo', motivo: 'Medicamento pode ser causa.' }
    ],
    orientacaoVerde: ['Orientar água, fibras, rotina intestinal e atividade física quando possível.', 'Laxativo leve pode ser considerado por curto prazo conforme perfil.'],
    orientacaoAmarela: ['Identificar medicamentos causadores e tempo de sintomas.', 'Encaminhar se persistente ou mudança recente.'],
    condutaVermelha: ['Encaminhar para avaliação médica/urgência.', 'Não indicar laxativo se suspeita de obstrução.'],
    mipPossiveis: ['Fibra/psyllium', 'Laxativo osmótico conforme perfil', 'Supositório em situação pontual conforme avaliação'],
    evitar: ['Laxante estimulante crônico', 'Uso sem hidratação', 'Laxativo em dor abdominal intensa']
  },
  {
    id: 'colica-menstrual',
    titulo: 'Cólica menstrual',
    categoria: 'Dor',
    resumo: 'Triagem para dismenorreia e sinais ginecológicos de alerta.',
    perguntas: [
      { id: 'gravidez', texto: 'Há possibilidade de gravidez, atraso menstrual importante ou sangramento intenso?', gravidade: 'vermelho', motivo: 'Precisa avaliação médica.' },
      { id: 'dor-forte', texto: 'Dor muito forte, febre, corrimento com odor ou dor pélvica fora do padrão?', gravidade: 'vermelho', motivo: 'Sinais de alerta ginecológico.' },
      { id: 'risco-ai', texto: 'Tem gastrite/úlcera, doença renal, usa anticoagulante ou tem hipertensão?', gravidade: 'amarelo', motivo: 'Cuidado com anti-inflamatórios.' },
      { id: 'inicio-tardio', texto: 'Cólica começou recentemente após anos sem dor ou piora a cada ciclo?', gravidade: 'amarelo', motivo: 'Pode precisar investigação.' }
    ],
    orientacaoVerde: ['Orientar calor local, hidratação e repouso relativo.', 'Analgésico/MIP pode ser considerado conforme perfil.'],
    orientacaoAmarela: ['Avaliar risco de anti-inflamatório e padrão da dor.', 'Encaminhar se recorrente intensa.'],
    condutaVermelha: ['Encaminhar para atendimento médico.', 'Não mascarar sinais ginecológicos importantes.'],
    mipPossiveis: ['Analgésico simples', 'Antiespasmódico conforme perfil', 'Calor local'],
    evitar: ['Anti-inflamatório em paciente de risco', 'Atrasar avaliação em suspeita de gravidez/infecção', 'Dose duplicada de analgésicos']
  }
];
