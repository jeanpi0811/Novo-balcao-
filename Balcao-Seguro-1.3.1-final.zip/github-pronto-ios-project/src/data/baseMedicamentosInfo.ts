import { Medicamento, StatusValidacaoMedicamento } from '../types';

export function contarStatusValidacao(medicamentos: Medicamento[]) {
  const inicial: Record<StatusValidacaoMedicamento, number> = {
    validado: 0,
    pre_validado: 0,
    parcial: 0,
    pendente: 0,
    desatualizado: 0
  };
  return medicamentos.reduce((acc, medicamento) => {
    const status = medicamento.statusValidacao ?? 'pendente';
    acc[status] += 1;
    return acc;
  }, inicial);
}

export function rotuloStatusValidacao(status?: StatusValidacaoMedicamento) {
  if (status === 'validado') return 'Validado c/ bula específica';
  if (status === 'pre_validado') return 'Pré-validado p/ balcão';
  if (status === 'parcial') return 'Registro/fonte parcial';
  if (status === 'desatualizado') return 'Revisão vencida';
  return 'Pendente de validação';
}

export function corStatusValidacao(status?: StatusValidacaoMedicamento): 'green' | 'yellow' | 'red' | 'muted' {
  if (status === 'validado') return 'green';
  if (status === 'pre_validado') return 'green';
  if (status === 'parcial') return 'yellow';
  if (status === 'desatualizado') return 'red';
  return 'muted';
}

export function validarParaUsoAmplo(medicamento: Medicamento) {
  return medicamento.statusValidacao === 'validado' && medicamento.bulaProfissionalConferida === true && medicamento.escopoValidacao === 'produto_especifico';
}
