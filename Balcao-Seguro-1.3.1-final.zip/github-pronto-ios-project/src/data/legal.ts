
export const termosAceiteInicial = [
  'O Balcão Seguro é uma ferramenta de apoio, organização e orientação informativa para atendimento farmacêutico. O aplicativo não realiza diagnóstico, não prescreve tratamento e não substitui consulta médica, atendimento presencial, bula, legislação sanitária, protocolos oficiais ou julgamento profissional.',
  'As informações exibidas devem ser conferidas antes de qualquer decisão. Cabe ao usuário/profissional verificar idade, peso quando aplicável, alergias, gestação, lactação, comorbidades, medicamentos em uso, contraindicações, interações, dose, forma farmacêutica, bula atualizada e protocolos locais.',
  'Sinais de alerta, sintomas graves, piora clínica, suspeita de urgência/emergência, uso em crianças, idosos frágeis, gestantes, lactantes, polimedicados ou pacientes com comorbidades exigem avaliação presencial e/ou encaminhamento adequado.',
  'Os registros do app são apoio documental local e não comprovam, por si só, diagnóstico, prescrição, atendimento médico ou validação integral da conduta. O usuário é responsável pelo conteúdo inserido e pela decisão tomada a partir das informações.',
  'Ao aceitar, o usuário declara ciência de que o uso do app é por sua conta e risco, assumindo integral responsabilidade pelas decisões tomadas, e isenta Jean Pierre Andres — CRF/RS 15974, desenvolvedores, colaboradores e o próprio aplicativo por danos, perdas, interpretações incorretas, uso inadequado ou condutas tomadas sem avaliação profissional, na máxima extensão permitida pela legislação aplicável.',
  'O app pode conter informações parciais, pendentes, desatualizadas ou dependentes de validação. Nenhuma informação deve ser usada como orientação clínica final sem conferência em fonte oficial e revisão profissional.'
];

export const declaracoesAceite = [
  'Li e entendi que o app é somente uma ferramenta de apoio e orientação informativa.',
  'Entendi que o app não faz diagnóstico, não prescreve medicamentos e não substitui avaliação médica ou farmacêutica presencial quando necessária.',
  'Assumo responsabilidade por conferir bula, protocolos, legislação, contraindicações, interações, alergias, faixa etária e condições do paciente antes de qualquer conduta.',
  'Declaro que isento Jean Pierre Andres — CRF/RS 15974, colaboradores, desenvolvedores e o aplicativo por uso inadequado, interpretação incorreta ou decisões tomadas fora de avaliação profissional, na máxima extensão permitida por lei.'
];

export const fontesDados = [
  'Dados Abertos da Anvisa — Medicamentos Registrados no Brasil: usado para conferir produto, princípio ativo, número de registro, situação e detentor do registro.',
  'Sistema de Consultas da Anvisa: usado para confirmação pública de produtos sujeitos à vigilância sanitária, registro, petições, publicações e Bulário Eletrônico.',
  'Bulário Eletrônico da Anvisa: fonte indicada para validar bula do paciente, bula profissional, contraindicações, advertências, interações e informações clínicas do produto específico.',
  'Curadoria farmacêutica: cada item clínico deve manter revisadoEm, revisadoPor, statusValidacao, fonte e observações de validação.',
  'Itens com status parcial ou pendente não devem ser tratados como orientação clínica final sem conferência da bula e julgamento profissional.'
];
export const termosUso = [
  'O Balcão Seguro é uma ferramenta de apoio e organização do atendimento, não um sistema de diagnóstico, prescrição automática ou substituto de avaliação profissional.',
  'Responsável pelo conteúdo farmacêutico inicial: Jean Pierre Andres — CRF/RS 15974.',
  'A identificação profissional no app não representa responsabilidade técnica por farmácia, drogaria, estabelecimento de saúde, loja, serviço de terceiros ou atendimento remoto fora das condições legais aplicáveis.',
  'As orientações exibidas devem ser conferidas pelo profissional responsável antes de qualquer conduta.',
  'Medicamentos com status parcial, pendente ou desatualizado exigem conferência em fonte oficial, bula profissional e protocolos locais antes de uso assistencial amplo.',
  'Sinais de alerta, casos graves, gestantes, crianças, idosos frágeis, pacientes polimedicados ou com comorbidades exigem avaliação cuidadosa e possível encaminhamento.',
  'O app não substitui bula, protocolos oficiais, legislação sanitária, avaliação médica ou julgamento clínico/farmacêutico.',
  'O responsável pelo atendimento deve revisar dose, forma farmacêutica, contraindicações, interações, alergias e particularidades do paciente.',
  'A base local deve ser validada e atualizada periodicamente antes de uso amplo.'
];
export const politicaPrivacidade = [
  'O app foi preparado para uso local/offline e não envia automaticamente registros para servidor.',
  'Os registros de atendimento ficam salvos no armazenamento local do aparelho.',
  'O usuário pode compartilhar manualmente um registro usando recursos do próprio sistema operacional.',
  'Não há login obrigatório nesta versão.',
  'Antes de publicação ampla, revisar SDKs, permissões e bibliotecas para confirmar a ausência de coleta indevida.',
  'Se forem adicionadas funções online, analytics, backup em nuvem ou suporte remoto, esta política deve ser atualizada.',
  'O usuário pode solicitar limpeza dos dados locais pelo menu Mais > Dados locais > Limpar dados locais.'
];
export const avisosSeguranca = [
  'Não usar como substituto de avaliação médica em sinais de gravidade.',
  'Sempre verificar alergias, idade, gestação, lactação, comorbidades e medicamentos em uso.',
  'Conferir bula e protocolos atualizados antes de orientar medicamento.',
  'Registrar a orientação dada e encaminhar quando houver risco.',
  'Base oficial validável não significa que todas as informações clínicas já estejam conferidas: observe o status de validação de cada item.'
];
