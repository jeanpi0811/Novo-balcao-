import { EnriquecimentoMedicamento, FonteMedicamento, Medicamento, StatusValidacaoMedicamento } from '../types';
import medicamentosImportadosJson from './medicamentos.importados.json';
import medicamentosEnriquecidosJson from './medicamentos.enriquecidos.json';
import { medicamentosSample } from './medicamentos.sample';

const tarjasPermitidas: Medicamento['tarja'][] = ['MIP', 'Tarja vermelha', 'Tarja preta', 'Controle especial', 'Outro'];
const statusPermitidos: StatusValidacaoMedicamento[] = ['validado', 'pre_validado', 'parcial', 'pendente', 'desatualizado'];

function texto(valor: unknown, fallback = ''): string { return typeof valor === 'string' && valor.trim() ? valor.trim() : fallback; }
function lista(valor: unknown): string[] { if (Array.isArray(valor)) return valor.map((item) => texto(item)).filter(Boolean); if (typeof valor === 'string') return valor.split('|').map((item) => item.trim()).filter(Boolean); return []; }
function slug(valor: string, index: number): string { const base = valor.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''); return base || `medicamento-${index + 1}`; }
function fontes(valor: unknown): FonteMedicamento[] { if (!Array.isArray(valor)) return []; return valor.filter((item): item is Record<string, unknown> => Boolean(item) && typeof item === 'object').map((item) => ({ tipo: texto(item.tipo, 'OUTRA') as FonteMedicamento['tipo'], titulo: texto(item.titulo, 'Fonte não informada'), url: texto(item.url) || undefined, acessadoEm: texto(item.acessadoEm) || undefined, observacao: texto(item.observacao) || undefined })); }
function status(valor: unknown): StatusValidacaoMedicamento { const bruto = texto(valor, 'pendente') as StatusValidacaoMedicamento; return statusPermitidos.includes(bruto) ? bruto : 'pendente'; }

function sanitizarMedicamento(item: unknown, index: number): Medicamento | null {
  if (!item || typeof item !== 'object') return null;
  const obj = item as Record<string, unknown>;
  const nome = texto(obj.nome ?? obj.NOME_PRODUTO ?? obj.PRODUTO);
  const principioAtivo = texto(obj.principioAtivo ?? obj.principio_ativo ?? obj.PRINCIPIO_ATIVO, nome);
  if (!nome || !principioAtivo) return null;
  const tarjaBruta = texto(obj.tarja, 'Outro') as Medicamento['tarja'];
  const tarja = tarjasPermitidas.includes(tarjaBruta) ? tarjaBruta : 'Outro';
  return {
    id: texto(obj.id, slug(nome, index)), nome, principioAtivo,
    classe: texto(obj.classe ?? obj.CLASSE_TERAPEUTICA ?? obj.CATEGORIA_REGULATORIA, 'Não informada'), tarja,
    forma: texto(obj.forma ?? obj.FORMA_FARMACEUTICA, 'Conferir apresentação'),
    dosagem: texto(obj.dosagem ?? obj.APRESENTACAO, 'Conferir apresentação'),
    referencia: texto(obj.referencia ?? obj.REFERENCIA) || undefined,
    genericos: lista(obj.genericos), similaresIntercambiaveis: lista(obj.similaresIntercambiaveis ?? obj.similares_intercambiaveis),
    alertas: lista(obj.alertas), contraindicacoes: lista(obj.contraindicacoes), statusValidacao: status(obj.statusValidacao),
    numeroRegistroAnvisa: texto(obj.numeroRegistroAnvisa ?? obj.NUMERO_REGISTRO_PRODUTO) || undefined,
    situacaoRegistro: texto(obj.situacaoRegistro ?? obj.SITUACAO_REGISTRO) || undefined,
    categoriaRegulatoria: texto(obj.categoriaRegulatoria ?? obj.CATEGORIA_REGULATORIA) || undefined,
    detentorRegistro: texto(obj.detentorRegistro ?? obj.EMPRESA_DETENTORA_REGISTRO) || undefined,
    dataRegistro: texto(obj.dataRegistro ?? obj.DATA_REGISTRO_PRODUTO) || undefined,
    dataVencimentoRegistro: texto(obj.dataVencimentoRegistro ?? obj.DATA_VENCIMENTO_REGISTRO) || undefined,
    revisadoEm: texto(obj.revisadoEm) || undefined, revisadoPor: texto(obj.revisadoPor) || undefined,
    fontes: fontes(obj.fontes), observacoesValidacao: lista(obj.observacoesValidacao),
    escopoValidacao: texto(obj.escopoValidacao, 'nao_definido') as Medicamento['escopoValidacao'],
    bulaProfissionalConferida: typeof obj.bulaProfissionalConferida === 'boolean' ? obj.bulaProfissionalConferida : false,
    revisaoVenceEm: texto(obj.revisaoVenceEm) || undefined,
    perguntasChave: lista(obj.perguntasChave), sinaisAlertaBalcao: lista(obj.sinaisAlertaBalcao), quandoEncaminhar: lista(obj.quandoEncaminhar)
  };
}

const importados = (Array.isArray(medicamentosImportadosJson) ? medicamentosImportadosJson : []).map(sanitizarMedicamento).filter((item): item is Medicamento => Boolean(item));
const enriquecidos = (Array.isArray(medicamentosEnriquecidosJson) ? medicamentosEnriquecidosJson : []) as EnriquecimentoMedicamento[];
const enriquecidosPorId = new Map(enriquecidos.map((item) => [item.id, item]));
const enriquecidosPorPrincipio = new Map(enriquecidos.map((item) => [item.principio_ativo.toLowerCase(), item]));

function anexarEnriquecimento(medicamento: Medicamento): Medicamento {
  const enriquecimento = enriquecidosPorId.get(medicamento.id) ?? enriquecidosPorPrincipio.get(medicamento.principioAtivo.toLowerCase());
  return enriquecimento ? { ...medicamento, enriquecimento } : medicamento;
}

const usados = new Set<string>();
export const medicamentos: Medicamento[] = [...importados, ...medicamentosSample]
  .map(anexarEnriquecimento)
  .filter((medicamento) => { const chave = `${medicamento.nome}|${medicamento.principioAtivo}`.toLowerCase(); if (usados.has(chave)) return false; usados.add(chave); return true; })
  .sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));

export const totalMedicamentosEnriquecidos = medicamentos.filter((medicamento) => Boolean(medicamento.enriquecimento)).length;
export const origemMedicamentos = importados.length > 0
  ? `Base local: ${importados.length} item(ns) pré-validados + ${totalMedicamentosEnriquecidos} item(ns) enriquecidos com triagem, grupos especiais, interações e fontes para conferência.`
  : 'Base local de exemplo. Importe o CSV oficial da Anvisa para ampliar.';
