import { Medicamento } from '../types';

export const medicamentosSample: Medicamento[] = [
  {
    id: 'paracetamol',
    nome: 'Paracetamol',
    principioAtivo: 'Paracetamol',
    classe: 'Analgésico/antitérmico',
    tarja: 'MIP',
    forma: 'Comprimido/Solução oral',
    dosagem: '500 mg / 750 mg / gotas conforme apresentação',
    referencia: 'Tylenol',
    genericos: ['Paracetamol genérico'],
    similaresIntercambiaveis: [],
    alertas: ['Atenção ao limite diário', 'Risco hepático em superdose ou uso com álcool'],
    contraindicacoes: ['Hipersensibilidade', 'Doença hepática grave sem avaliação']
  },
  {
    id: 'dipirona',
    nome: 'Dipirona',
    principioAtivo: 'Dipirona monoidratada',
    classe: 'Analgésico/antitérmico',
    tarja: 'MIP',
    forma: 'Comprimido/Gotas/Solução oral',
    dosagem: '500 mg / 1 g / gotas conforme apresentação',
    referencia: 'Novalgina',
    genericos: ['Dipirona genérica'],
    similaresIntercambiaveis: [],
    alertas: ['Checar alergia prévia', 'Cautela em queda de pressão'],
    contraindicacoes: ['Hipersensibilidade a pirazolonas', 'Histórico de reações hematológicas relacionadas']
  },
  {
    id: 'ibuprofeno',
    nome: 'Ibuprofeno',
    principioAtivo: 'Ibuprofeno',
    classe: 'Anti-inflamatório não esteroidal',
    tarja: 'MIP',
    forma: 'Comprimido/Suspensão',
    dosagem: '200 mg / 400 mg / suspensão conforme apresentação',
    referencia: 'Advil/Alivium',
    genericos: ['Ibuprofeno genérico'],
    similaresIntercambiaveis: [],
    alertas: ['Cautela em hipertensão, doença renal, gastrite/úlcera e anticoagulantes', 'Evitar automedicação prolongada'],
    contraindicacoes: ['Úlcera ativa sem avaliação', 'Doença renal importante', 'Alergia a AINEs']
  },
  {
    id: 'loratadina',
    nome: 'Loratadina',
    principioAtivo: 'Loratadina',
    classe: 'Antihistamínico',
    tarja: 'MIP',
    forma: 'Comprimido/Xarope',
    dosagem: '10 mg / xarope conforme apresentação',
    referencia: 'Claritin',
    genericos: ['Loratadina genérica'],
    similaresIntercambiaveis: [],
    alertas: ['Checar idade e gestação', 'Menor sedação que antihistamínicos antigos, mas pode ocorrer sonolência'],
    contraindicacoes: ['Hipersensibilidade']
  },
  {
    id: 'omeprazol',
    nome: 'Omeprazol',
    principioAtivo: 'Omeprazol',
    classe: 'Inibidor de bomba de prótons',
    tarja: 'Tarja vermelha',
    forma: 'Cápsula',
    dosagem: '10 mg / 20 mg / 40 mg conforme apresentação',
    referencia: 'Losec',
    genericos: ['Omeprazol genérico'],
    similaresIntercambiaveis: [],
    alertas: ['Evitar uso prolongado sem acompanhamento', 'Investigar sinais de alarme gastrointestinal'],
    contraindicacoes: ['Hipersensibilidade']
  },
  {
    id: 'loperamida',
    nome: 'Loperamida',
    principioAtivo: 'Cloridrato de loperamida',
    classe: 'Antidiarreico',
    tarja: 'MIP',
    forma: 'Comprimido/Cápsula',
    dosagem: '2 mg',
    referencia: 'Imosec',
    genericos: ['Loperamida genérica'],
    similaresIntercambiaveis: [],
    alertas: ['Não usar se diarreia com sangue ou febre alta', 'Priorizar reidratação'],
    contraindicacoes: ['Disenteria aguda', 'Colite grave', 'Crianças pequenas sem orientação']
  }
];
