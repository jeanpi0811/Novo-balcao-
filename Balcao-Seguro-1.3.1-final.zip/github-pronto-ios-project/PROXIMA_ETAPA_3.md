# Próxima etapa 3 — Publicação/distribuição

Decisão necessária: como o app será distribuído?

## Opção A — APK direto
Mais simples para testar e instalar manualmente em celulares Android.

Precisa:
- Gerar APK release.
- Assinar com keystore definitiva.
- Testar instalação em Android físico.

## Opção B — Play Store
Mais profissional, mas exige conta Google Play Console, política de privacidade em URL pública e AAB assinado.

Precisa:
- Criar/usar conta Google Play Console.
- Gerar AAB release.
- Ter política de privacidade online.
- Definir categoria, descrição curta, descrição completa, screenshots e ícone.

## Opção C — Uso interno/farmácia
Melhor para piloto controlado. Pode usar APK direto ou teste interno da Play Store.

Próxima pergunta sugerida:
Você quer preparar primeiro para APK direto, Play Store ou os dois?
