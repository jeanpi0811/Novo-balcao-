# Checklist de testes comerciais — v1.2.6

## Visual

- [ ] Home sem logo/quadrado girando no fundo.
- [ ] Cards com visual glass discreto.
- [ ] Tela vertical em celular legível.
- [ ] Tela horizontal/HTV sem quebrar layout.
- [ ] Barra inferior com 5 abas: Início, Atendimento, Medicamentos, Interações, Mais.

## Fluxo Grátis/Pro

- [ ] Consulta básica de medicamentos abre sem Pro.
- [ ] Atendimento completo pede Pro quando Pro está inativo.
- [ ] Interações pede Pro quando Pro está inativo.
- [ ] Registros pede Pro quando Pro está inativo.
- [ ] Área Admin libera Pro localmente.
- [ ] Após liberar Pro, Atendimento/Interações/Registros abrem.
- [ ] Revogar Pro bloqueia novamente os recursos.

## Aba Mais

- [ ] Administração do aplicativo aparece.
- [ ] PIN Admin 274798 funciona.
- [ ] Sobre abre.
- [ ] Base de medicamentos abre.
- [ ] Termos de uso abre.
- [ ] Política de privacidade abre.
- [ ] Suporte abre WhatsApp.
- [ ] Exportar dados abre compartilhamento JSON.
- [ ] Limpar dados locais pede confirmação forte.

## Segurança e responsabilidade

- [ ] Termos de uso aparecem corretamente.
- [ ] Política de privacidade informa dados locais.
- [ ] Responsável: Jean Pierre Andres — CRF/RS 15974.
- [ ] Aviso profissional claro: app não substitui julgamento clínico/farmacêutico.

## Build

- [ ] APK Android gerado.
- [ ] AAB Android gerado, se necessário.
- [ ] iOS abre pelo .xcworkspace.
- [ ] iPhone físico compila em Debug.
