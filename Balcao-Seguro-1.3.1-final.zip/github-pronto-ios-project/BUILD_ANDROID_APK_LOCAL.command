#!/bin/bash
bash ./scripts/fix_gradle_wrapper.sh 2>/dev/null || true
set -e
cd "$(dirname "$0")"
./GERAR_APK_FINAL.command
