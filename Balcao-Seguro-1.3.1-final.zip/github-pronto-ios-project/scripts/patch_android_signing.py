from pathlib import Path
import re

app_gradle = Path('android/app/build.gradle')
if not app_gradle.exists():
    raise SystemExit('android/app/build.gradle não encontrado. Rode expo prebuild primeiro.')

s = app_gradle.read_text()

def find_matching_brace(text, open_brace_index):
    depth = 0
    for i in range(open_brace_index, len(text)):
        ch = text[i]
        if ch == '{':
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                return i
    return -1

def find_block(text, name, start=0, end=None):
    if end is None:
        end = len(text)
    m = re.search(r'\b' + re.escape(name) + r'\s*\{', text[start:end])
    if not m:
        return None
    block_start = start + m.start()
    brace = start + m.end() - 1
    close = find_matching_brace(text, brace)
    if close < 0:
        return None
    return block_start, brace, close

# Remove linha inserida por versões antigas do patch dentro do bloco signingConfigs.release.
s = re.sub(r'\n\s*signingConfig\s+signingConfigs\.release(?=\n\s*})', '', s)

# Ensure keystore loader exists before android { ... }
if 'balcaoSeguroKeystoreProperties' not in s:
    marker = 'android {'
    inject = """

def balcaoSeguroKeystoreProperties = new Properties()
def balcaoSeguroKeystorePropertiesFile = rootProject.file(\"balcao-seguro-keystore.properties\")
if (balcaoSeguroKeystorePropertiesFile.exists()) {
    balcaoSeguroKeystoreProperties.load(new FileInputStream(balcaoSeguroKeystorePropertiesFile))
}

"""
    if marker not in s:
        raise SystemExit('Bloco android { não encontrado em build.gradle.')
    s = s.replace(marker, inject + marker, 1)

android = find_block(s, 'android')
if not android:
    raise SystemExit('Bloco android { } não encontrado em build.gradle.')
android_start, android_brace, android_close = android

release_signing_block = """
        release {
            if (balcaoSeguroKeystorePropertiesFile.exists()) {
                storeFile rootProject.file(balcaoSeguroKeystoreProperties['storeFile'])
                storePassword balcaoSeguroKeystoreProperties['storePassword']
                keyAlias balcaoSeguroKeystoreProperties['keyAlias']
                keyPassword balcaoSeguroKeystoreProperties['keyPassword']
            }
        }
"""

# Ensure android { signingConfigs { release { ... } } }
android = find_block(s, 'android')
android_start, android_brace, android_close = android
signing = find_block(s, 'signingConfigs', android_brace, android_close)
if not signing:
    default = find_block(s, 'defaultConfig', android_brace, android_close)
    if not default:
        raise SystemExit('Bloco defaultConfig { } não encontrado para inserir signingConfigs.')
    insert_at = default[0]
    signing_text = """    signingConfigs {""" + release_signing_block + """    }

"""
    s = s[:insert_at] + signing_text + s[insert_at:]
else:
    sign_start, sign_brace, sign_close = signing
    sign_block = s[sign_start:sign_close+1]
    if not re.search(r'\brelease\s*\{', sign_block):
        s = s[:sign_close] + release_signing_block + s[sign_close:]

# Recompute after modifications
android = find_block(s, 'android')
android_start, android_brace, android_close = android

# Ensure android { buildTypes { release { signingConfig signingConfigs.release } } }
build_types = find_block(s, 'buildTypes', android_brace, android_close)
if not build_types:
    insert_at = android_close
    build_types_text = """
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled false
            shrinkResources false
        }
    }
"""
    s = s[:insert_at] + build_types_text + s[insert_at:]
else:
    bt_start, bt_brace, bt_close = build_types
    release = find_block(s, 'release', bt_brace, bt_close)
    if not release:
        insert_at = bt_close
        release_text = """
        release {
            signingConfig signingConfigs.release
            minifyEnabled false
            shrinkResources false
        }
"""
        s = s[:insert_at] + release_text + s[insert_at:]
    else:
        r_start, r_brace, r_close = release
        block = s[r_start:r_close+1]
        block = block.replace('signingConfig signingConfigs.debug', 'signingConfig signingConfigs.release')
        if 'signingConfig signingConfigs.release' not in block:
            block = block[:block.find('{')+1] + '\n            signingConfig signingConfigs.release' + block[block.find('{')+1:]
        s = s[:r_start] + block + s[r_close+1:]

app_gradle.write_text(s)
print('OK: android/app/build.gradle ajustado para assinatura release sem signingConfig no bloco errado.')
