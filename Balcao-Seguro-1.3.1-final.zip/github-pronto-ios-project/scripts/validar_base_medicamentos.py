#!/usr/bin/env python3
from pathlib import Path
import json, sys, re, datetime
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'src' / 'data' / 'medicamentos.importados.json'
REQUIRED = ['id','nome','principioAtivo','classe','tarja','forma','dosagem','alertas','contraindicacoes','statusValidacao','fontes']
VALID_STATUSES = {'validado','pre_validado','parcial','pendente','desatualizado'}

def main():
    errors=[]; warnings=[]
    meds = json.loads(DATA.read_text(encoding='utf-8'))
    seen=set()
    for i,m in enumerate(meds, start=1):
        label = m.get('nome') or f'linha {i}'
        for k in REQUIRED:
            if k not in m or m[k] in ('', None, []): errors.append(f'{label}: campo obrigatório vazio/ausente: {k}')
        if m.get('id') in seen: errors.append(f'{label}: id duplicado: {m.get("id")}')
        seen.add(m.get('id'))
        if m.get('statusValidacao') not in VALID_STATUSES: errors.append(f'{label}: status inválido: {m.get("statusValidacao")}')
        fontes = m.get('fontes') or []
        tipos = {f.get('tipo') for f in fontes if isinstance(f, dict)}
        if 'ANVISA_BULARIO' not in tipos: warnings.append(f'{label}: sem fonte ANVISA_BULARIO cadastrada')
        if 'ANVISA_CONSULTAS' not in tipos and 'ANVISA_DADOS_ABERTOS' not in tipos: warnings.append(f'{label}: sem fonte regulatória Anvisa cadastrada')
        if m.get('statusValidacao') == 'validado':
            if m.get('escopoValidacao') != 'produto_especifico': errors.append(f'{label}: validado final exige escopo produto_especifico')
            if m.get('bulaProfissionalConferida') is not True: errors.append(f'{label}: validado final exige bulaProfissionalConferida=true')
            if not m.get('numeroRegistroAnvisa'): errors.append(f'{label}: validado final exige numeroRegistroAnvisa')
        if m.get('statusValidacao') == 'pre_validado' and m.get('bulaProfissionalConferida') is True:
            warnings.append(f'{label}: pré-validado com bulaProfissionalConferida=true; considere status validado se for produto específico')
        for arr in ['perguntasChave','sinaisAlertaBalcao','quandoEncaminhar']:
            if len(m.get(arr) or []) < 2: warnings.append(f'{label}: {arr} tem menos de 2 itens')
    report = ROOT / 'RELATORIO_VALIDACAO_BASE_ETAPA5.txt'
    lines = [
        'Balcão Seguro — validação de base etapa 5',
        f'Gerado em: {datetime.datetime.now().isoformat(timespec="seconds")}',
        f'Total de medicamentos: {len(meds)}',
        f'Erros: {len(errors)}',
        f'Avisos: {len(warnings)}',
        '', 'ERROS:'
    ] + (errors or ['Nenhum erro bloqueante encontrado.']) + ['', 'AVISOS:'] + (warnings or ['Nenhum aviso.'])
    report.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))
    return 1 if errors else 0
if __name__ == '__main__': sys.exit(main())
