from pathlib import Path
import re

manifest = Path('android/app/src/main/AndroidManifest.xml')
if not manifest.exists():
    raise SystemExit('AndroidManifest.xml não encontrado. Rode expo prebuild primeiro.')

s = manifest.read_text()

# Garante namespace tools quando precisarmos sobrescrever allowBackup gerado por libs/configs.
if 'xmlns:tools=' not in s:
    s = s.replace('<manifest ', '<manifest xmlns:tools="http://schemas.android.com/tools" ', 1)

# Ajusta allowBackup dentro da tag <application ...>.
match = re.search(r'<application\b[^>]*>', s)
if not match:
    raise SystemExit('Tag <application> não encontrada no AndroidManifest.xml')

tag = match.group(0)
if 'android:allowBackup=' in tag:
    tag2 = re.sub(r'android:allowBackup="[^"]*"', 'android:allowBackup="false"', tag)
else:
    tag2 = tag[:-1] + ' android:allowBackup="false">'

if 'tools:replace=' in tag2:
    if 'android:allowBackup' not in tag2:
        tag2 = re.sub(r'tools:replace="([^"]*)"', r'tools:replace="\1,android:allowBackup"', tag2)
else:
    tag2 = tag2[:-1] + ' tools:replace="android:allowBackup">'

s = s[:match.start()] + tag2 + s[match.end():]
manifest.write_text(s)
print('OK: AndroidManifest.xml ajustado com android:allowBackup="false".')
