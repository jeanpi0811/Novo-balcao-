#!/usr/bin/env python3
import json, sys
from pathlib import Path

BASE = Path('src/data/medicamentos.enriquecidos.json')
REQUIRED_TOP = [
    'id','nome','principio_ativo','classe_terapeutica','uso_orientativo','alertas',
    'grupos_especiais','interacoes','efeitos_adversos','triagem_farmaceutica',
    'resumo_leigo','aviso_responsabilidade','fontes','status_validacao'
]
GROUPS = ['criancas','idosos','gestantes','lactantes','renal','hepatica','hipertensao','diabetes','cardiopatia','anticoagulantes','alergias']
CLASSIFICACOES = {'permitido com orientação','usar com cautela','evitar sem avaliação profissional','contraindicado','não encontrado em fonte oficial'}
GRAVIDADES = {'leve','moderada','grave','contraindicada'}

def erro(msg):
    print(f'ERRO: {msg}')
    return 1

def main():
    if not BASE.exists():
        return erro(f'Arquivo não encontrado: {BASE}')
    data = json.loads(BASE.read_text(encoding='utf-8'))
    if not isinstance(data, list):
        return erro('A base enriquecida deve ser uma lista JSON.')
    failures = []
    warnings = []
    ids = set()
    for idx, item in enumerate(data, 1):
        if not isinstance(item, dict):
            failures.append(f'Item {idx}: não é objeto JSON.')
            continue
        for key in REQUIRED_TOP:
            if key not in item:
                failures.append(f'{item.get("id", idx)}: faltando campo {key}.')
        if item.get('id') in ids:
            failures.append(f'ID duplicado: {item.get("id")}')
        ids.add(item.get('id'))
        grupos = item.get('grupos_especiais', {})
        for g in GROUPS:
            grupo = grupos.get(g, {})
            if grupo.get('classificacao') not in CLASSIFICACOES:
                failures.append(f'{item.get("id")}: classificação inválida em {g}: {grupo.get("classificacao")}')
            if not grupo.get('observacao'):
                warnings.append(f'{item.get("id")}: observação vazia em {g}.')
        for i, inter in enumerate(item.get('interacoes', []), 1):
            if inter.get('gravidade') not in GRAVIDADES:
                failures.append(f'{item.get("id")}: interação {i} com gravidade inválida: {inter.get("gravidade")}')
            for key in ['com','classe_ou_medicamento','mecanismo_simples','consequencia','orientacao_segura','fonte']:
                if not inter.get(key):
                    warnings.append(f'{item.get("id")}: interação {i} sem {key}.')
        fontes = item.get('fontes', [])
        if not fontes:
            warnings.append(f'{item.get("id")}: sem fontes.')
        if item.get('status_validacao', {}).get('validado') is True:
            warnings.append(f'{item.get("id")}: marcado como validado final; conferir revisão manual.')
    print(f'Base enriquecida: {len(data)} item(ns) analisados.')
    print(f'Falhas: {len(failures)}')
    print(f'Avisos: {len(warnings)}')
    for msg in failures[:50]:
        print(' -', msg)
    if warnings:
        print('\nPrimeiros avisos:')
        for msg in warnings[:25]:
            print(' -', msg)
    return 1 if failures else 0

if __name__ == '__main__':
    sys.exit(main())
