import fs from 'node:fs';
import path from 'node:path';

const entrada = process.argv[2];
const saida = process.argv[3] ?? 'src/data/medicamentos.importados.json';

if (!entrada) {
  console.error('Uso: node scripts/importar_csv_node.mjs arquivo.csv saida.json');
  process.exit(1);
}

function parseCSV(texto) {
  const linhas = [];
  let atual = '';
  let linha = [];
  let dentroAspas = false;

  for (let i = 0; i < texto.length; i++) {
    const char = texto[i];
    const prox = texto[i + 1];

    if (char === '"' && dentroAspas && prox === '"') {
      atual += '"';
      i++;
    } else if (char === '"') {
      dentroAspas = !dentroAspas;
    } else if (char === ',' && !dentroAspas) {
      linha.push(atual.trim());
      atual = '';
    } else if ((char === '\n' || char === '\r') && !dentroAspas) {
      if (char === '\r' && prox === '\n') i++;
      linha.push(atual.trim());
      if (linha.some(Boolean)) linhas.push(linha);
      atual = '';
      linha = [];
    } else {
      atual += char;
    }
  }

  if (atual || linha.length) {
    linha.push(atual.trim());
    if (linha.some(Boolean)) linhas.push(linha);
  }

  return linhas;
}

function lista(valor) {
  if (!valor) return [];
  return valor.split('|').map((item) => item.trim()).filter(Boolean);
}

const texto = fs.readFileSync(entrada, 'utf8');
const linhas = parseCSV(texto);
const cabecalho = linhas.shift().map((h) => h.trim());

const medicamentos = linhas.map((linha, index) => {
  const obj = Object.fromEntries(cabecalho.map((coluna, i) => [coluna, linha[i] ?? '']));
  return {
    id: `${obj.nome || 'medicamento'}-${index + 1}`.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-'),
    nome: obj.nome,
    principioAtivo: obj.principio_ativo,
    classe: obj.classe,
    tarja: obj.tarja || 'Outro',
    forma: obj.forma,
    dosagem: obj.dosagem,
    referencia: obj.referencia,
    genericos: lista(obj.genericos),
    similaresIntercambiaveis: lista(obj.similares_intercambiaveis),
    alertas: lista(obj.alertas),
    contraindicacoes: lista(obj.contraindicacoes)
  };
});

fs.mkdirSync(path.dirname(saida), { recursive: true });
fs.writeFileSync(saida, JSON.stringify(medicamentos, null, 2));
console.log(`Importados ${medicamentos.length} medicamentos para ${saida}`);
