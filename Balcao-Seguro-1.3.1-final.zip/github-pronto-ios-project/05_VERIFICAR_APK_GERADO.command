#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

APK="${1:-Balcao-Seguro-v1.1.6-release-sem-servidor.apk}"
if [ ! -f "$APK" ]; then
  echo "ERRO: APK não encontrado: $APK"
  exit 1
fi

echo "Arquivo: $APK"
ls -lh "$APK"

echo ""
echo "== Validando se o APK tem JS embutido e não depende de servidor Metro =="
python3 ./scripts/validar_apk_sem_servidor.py "$APK"

echo ""
echo "== Permissões no Manifest, se aapt existir =="
if command -v aapt >/dev/null 2>&1; then
  aapt dump permissions "$APK" || true
else
  echo "aapt não encontrado; pulando dump de permissões."
fi
