#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "============================================"
echo " Balcão Seguro — gerar ios/ local/offline"
echo "============================================"

echo "Este script NÃO usa EAS, nuvem ou build online."
echo "Ele só funciona offline se node_modules, Xcode, CocoaPods e caches já existirem neste Mac."
echo ""

if [[ "$(uname)" != "Darwin" ]]; then
  echo "ERRO: iOS/Xcode só funciona no macOS."
  exit 1
fi

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "ERRO: Xcode/Command Line Tools não encontrados."
  exit 1
fi

if [ ! -d "node_modules" ]; then
  echo "ERRO: node_modules não existe."
  echo "Sem node_modules não existe geração iOS offline real. Rode uma vez com internet:"
  echo "./PREPARAR_CACHE_ONLINE_UMA_VEZ.command"
  exit 1
fi

if [ ! -x "node_modules/.bin/expo" ]; then
  echo "ERRO: Expo CLI local não encontrado em node_modules/.bin/expo"
  exit 1
fi

echo "== Gerando/atualizando ios/ sem instalar pacotes =="
./node_modules/.bin/expo prebuild -p ios --no-install

if [ -d "ios" ] && command -v pod >/dev/null 2>&1; then
  echo "== Tentando instalar Pods usando cache local =="
  cd ios
  pod install --deployment || pod install --no-repo-update || true
  cd ..
else
  echo "Aviso: CocoaPods não encontrado ou pasta ios/ ausente. Abra no Xcode e deixe ele apontar o erro de Pods se faltar."
fi

echo "== Abrindo no Xcode =="
if command -v xed >/dev/null 2>&1; then
  xed ios
else
  open ios/*.xcworkspace 2>/dev/null || open ios
fi

echo ""
echo "No Xcode: Signing & Capabilities > Team > selecione sua Apple ID > escolha o iPhone > Run."
