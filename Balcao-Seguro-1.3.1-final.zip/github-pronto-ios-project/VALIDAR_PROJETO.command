#!/bin/bash
set -e
cd "$(dirname "$0")"

export EXPO_NO_TELEMETRY=1

echo "== Validando TypeScript =="
npx tsc --noEmit

echo "== Conferindo Expo/React Native =="
npx expo-doctor || true

echo ""
echo "Validação concluída."
