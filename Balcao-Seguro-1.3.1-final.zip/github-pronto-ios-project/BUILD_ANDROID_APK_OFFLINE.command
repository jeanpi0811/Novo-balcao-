#!/bin/bash
bash ./scripts/fix_gradle_wrapper.sh 2>/dev/null || true
set -e
cd "$(dirname "$0")"

echo "============================================"
echo " Balcão Seguro — APK local/offline"
echo "============================================"

echo "Este script NÃO usa EAS, nuvem ou build online."
echo "Ele só funciona offline se node_modules, Android SDK, Gradle e caches já existirem neste Mac."
echo ""

if [ ! -d "node_modules" ]; then
  echo "ERRO: node_modules não existe."
  echo "Sem node_modules não existe build offline real. Rode uma vez com internet:"
  echo "./PREPARAR_CACHE_ONLINE_UMA_VEZ.command"
  exit 1
fi

if [ ! -x "node_modules/.bin/expo" ]; then
  echo "ERRO: Expo CLI local não encontrado em node_modules/.bin/expo"
  exit 1
fi

echo "== Gerando/atualizando android/ sem instalar pacotes =="
./node_modules/.bin/expo prebuild -p android --no-install

if [ ! -d "android" ]; then
  echo "ERRO: pasta android/ não foi gerada."
  exit 1
fi

echo "== Compilando APK offline via Gradle =="
cd android
chmod +x ./gradlew
./gradlew assembleRelease --offline
cd ..

echo ""
echo "APK gerado em:"
echo "android/app/build/outputs/apk/release/app-release.apk"
