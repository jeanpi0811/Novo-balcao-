# Revisão técnica — Balcão Seguro 1.2.8

## Correções implementadas

A busca de medicamentos passou a priorizar correspondências exatas e correspondências no início do nome ou princípio ativo. Isso evita que um termo válido seja escondido por resultados menos relevantes na base local.

A tela **Interações** deixou de escolher silenciosamente o primeiro item encontrado. Agora cada campo apresenta candidatos clicáveis com nome, princípio ativo e classe terapêutica. O usuário precisa selecionar explicitamente um medicamento em cada campo antes de liberar a checagem.

Foi adicionado um comando visível **‹ Voltar** às telas de Medicamentos e Interações. A navegação do aplicativo agora mantém histórico entre telas, e o botão físico de voltar do Android retorna à tela anterior quando existe histórico.

## Preparação para publicação

A versão foi atualizada para **1.2.8**. O Android `versionCode` foi atualizado para **17**. Permissões Android desnecessárias para o funcionamento offline foram removidas do manifesto de release: leitura/escrita de armazenamento, janela sobre outros aplicativos e vibração. O aplicativo mantém somente a configuração necessária ao funcionamento do pacote atual.

O projeto continua offline, sem login e sem envio automático de registros para servidores. A política de privacidade e o checklist da Play Store foram mantidos no diretório `PUBLICACAO_PLAY_STORE`.

## Validações

- TypeScript: aprovado após a correção do token de tema.
- Expo Doctor: 21 de 22 verificações aprovadas.
- Único alerta: regressão conhecida de memória do Hermes V1 no Expo SDK 56. O SDK 57 corrige o problema, mas a migração deve ser feita em uma etapa separada e testada, pois altera React Native, Xcode e dependências nativas.
- Validação da base enriquecida: executada antes do build release.
- Build Android release: gerado separadamente e verificado como artefato APK.

## Pendências externas antes da loja

A publicação exige uma conta de desenvolvedor, URL pública da política de privacidade, screenshots reais, classificação indicativa, formulário de Segurança dos dados, assinatura final sob responsabilidade do proprietário da conta e teste fechado/interno. O Premium também não deve ser anunciado como compra funcional enquanto as chaves da loja e a integração Apple/Google Billing/RevenueCat não estiverem configuradas.

O APK release é apropriado para instalação direta e testes. Para Google Play, deve-se gerar e assinar um **AAB** com a chave de produção da conta do desenvolvedor.
