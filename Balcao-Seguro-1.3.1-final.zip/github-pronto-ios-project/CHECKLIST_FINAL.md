# Checklist final — Balcão Seguro

## Feito até a etapa 2
- App configurado como offline, sem login e sem envio automático de dados.
- Telas de Sobre, Termos, Privacidade e Fontes adicionadas.
- Avisos de segurança visíveis no app.
- Registros limitados a 200 atendimentos locais para evitar crescimento indefinido.
- Compartilhamento de registro inclui aviso de responsabilidade.
- Contato público de suporte definido: WhatsApp (54) 99142-7519.
- Responsável pelo conteúdo farmacêutico exibido no app: Jean Pierre Andres — CRF/RS 15974.
- Termos e privacidade atualizados com responsável, contato e aviso de não substituição de RT por estabelecimento.
- Scripts de APK/AAB release mantidos.

## Ainda precisa decidir antes de publicar
1. Nome exato que aparecerá na Play Store/fora dela: manter “Balcão Seguro” ou trocar.
2. Nome do publicador/desenvolvedor: pessoa física, empresa ou marca.
3. Validação completa da base de medicamentos e fontes.
4. Keystore definitiva para Android.
5. Teste em Android físico com APK release.
6. AAB final para Play Store, caso publique.
7. Política de privacidade final em uma URL pública, caso publique na Play Store.

## Comandos principais
```bash
chmod +x *.command
./VALIDAR_PROJETO.command
./GERAR_APK_FINAL.command
./GERAR_AAB_PLAY_STORE.command
```
