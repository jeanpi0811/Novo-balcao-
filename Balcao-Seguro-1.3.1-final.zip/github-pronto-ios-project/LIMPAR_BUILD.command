#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

echo "Isso remove android/, ios/ e saídas de build, mas mantém o código-fonte."
read -p "Continuar? [s/N] " resp
case "$resp" in
  s|S|sim|SIM)
    rm -rf android ios .expo dist build
    rm -f Balcao-Seguro-v1.0.0-final.apk Balcao-Seguro-v1.0.0-playstore.aab
    echo "Limpo."
    ;;
  *) echo "Cancelado." ;;
esac
