#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "============================================"
echo " Balcão Seguro — gerar pasta ios/ e abrir Xcode"
echo "============================================"

if [[ "$(uname)" != "Darwin" ]]; then
  echo "ERRO: iOS/Xcode só funciona no macOS."
  exit 1
fi

if ! command -v node >/dev/null 2>&1; then
  echo "ERRO: Node.js não encontrado. Instale Node.js ou Homebrew + node."
  echo "Sugestão: brew install node"
  exit 1
fi

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "ERRO: Xcode/Command Line Tools não encontrados."
  echo "Instale o Xcode pela App Store e depois rode: sudo xcode-select -s /Applications/Xcode.app/Contents/Developer"
  exit 1
fi

echo "== Instalando dependências npm =="
npm install

echo "== Ajustando versões Expo =="
npx expo install --fix || true

echo "== Gerando pasta ios/ =="
npx expo prebuild -p ios

if command -v pod >/dev/null 2>&1 && [ -d "ios" ]; then
  echo "== Rodando pod install =="
  cd ios
  pod install || true
  cd ..
fi

echo "== Abrindo projeto iOS no Xcode =="
if command -v xed >/dev/null 2>&1; then
  xed ios
else
  open ios/*.xcworkspace 2>/dev/null || open ios
fi

echo ""
echo "Pronto. No Xcode:"
echo "1) Conecte o iPhone por cabo e confie no computador."
echo "2) Abra Signing & Capabilities."
echo "3) Selecione seu Team/Apple ID."
echo "4) Ajuste Bundle Identifier se necessário."
echo "5) Selecione o iPhone no topo e clique em Run."
