#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

export EXPO_NO_TELEMETRY=1
LOG="build-aab-playstore-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee "$LOG") 2>&1

echo "============================================"
echo " Balcão Seguro — gerar AAB Play Store"
echo "============================================"
echo "Log: $LOG"

if [ ! -d "node_modules" ]; then
  npm install

echo "== Ajustando versões compatíveis com Expo =="
npx expo install --fix || true
fi

npx tsc --noEmit
npx expo prebuild -p android --clean
cd android
chmod +x ./gradlew
./gradlew bundleRelease
cd ..

echo "AAB gerado em: android/app/build/outputs/bundle/release/app-release.aab"
