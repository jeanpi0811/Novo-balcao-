# Próxima etapa 6

Agora o passo correto é gerar o APK/AAB no Mac e me mandar o resultado.

## Faça assim

```bash
chmod +x *.command scripts/*.py scripts/*.sh
./10_GERAR_APK_AAB_COM_LOG.command
```

## Me mande de volta

1. `app-release.apk`, se gerar;
2. `app-release.aab`, se gerar;
3. o arquivo `build-final-etapa5-*.log`, mesmo se der erro.

Com isso eu consigo analisar se o APK ficou release, se tem JS embutido, se o splash/ícone entraram corretamente e se ainda existe configuração de debug.
