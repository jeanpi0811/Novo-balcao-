# Etapa 5 — APK/AAB + base prioritária pré-validada

## O que foi feito

1. O projeto foi preparado para o caminho **APK direto + AAB Play Store**.
2. O `tsconfig.json` foi reforçado para JSX/ES2020 e inclusão explícita dos arquivos do app.
3. A base de medicamentos ganhou um nível intermediário: `pre_validado`.
4. Foram adicionados 27 princípios ativos prioritários com checklist de balcão:
   - perguntas-chave;
   - sinais de alerta;
   - critérios de encaminhamento;
   - fontes Anvisa e curadoria farmacêutica;
   - vencimento de revisão.
5. Nenhum item foi marcado como `validado` final sem bula profissional de produto específico.

## Status correto dos medicamentos

- `pre_validado`: serve como checklist profissional de balcão por princípio ativo.
- `validado`: reservado para produto específico com registro Anvisa, bula profissional conferida, data de revisão e responsável.

Essa separação evita falsa segurança clínica.

## Como tentar o build final no Mac

```bash
chmod +x *.command scripts/*.py scripts/*.sh
./09_VALIDAR_PRE_BUILD.command
./10_GERAR_APK_AAB_COM_LOG.command
```

Se falhar, me mande o arquivo `build-final-etapa5-*.log`.
