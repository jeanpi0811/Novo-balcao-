#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "== Balcão Seguro: validação estrutural da base de medicamentos =="
python3 - <<'PY'
import json
from pathlib import Path
p = Path('src/data/medicamentos.importados.json')
data = json.loads(p.read_text(encoding='utf-8'))
required = ['id','nome','principioAtivo','classe','tarja','forma','dosagem','alertas','contraindicacoes','statusValidacao','fontes']
valid_status = {'validado','parcial','pendente','desatualizado'}
errors = []
for i, item in enumerate(data, 1):
    for key in required:
        if key not in item or item[key] in ('', None, []):
            errors.append(f'Item {i}: campo obrigatório ausente/vazio: {key}')
    if item.get('statusValidacao') not in valid_status:
        errors.append(f'Item {i}: statusValidacao inválido: {item.get("statusValidacao")}')
    if item.get('statusValidacao') == 'validado':
        tipos = {f.get('tipo') for f in (item.get('fontes') or []) if isinstance(f, dict)}
        if 'BULA_PROFISSIONAL' not in tipos and 'ANVISA_BULARIO' not in tipos:
            errors.append(f'Item {i}: marcado como validado sem fonte de bula/Bulário: {item.get("nome")}')
print(f'Total de itens: {len(data)}')
for status in sorted(valid_status):
    print(f'{status}:', sum(1 for item in data if item.get('statusValidacao') == status))
if errors:
    print('\nERROS:')
    for err in errors[:80]:
        print('-', err)
    if len(errors) > 80:
        print(f'... e mais {len(errors)-80} erro(s).')
    raise SystemExit(1)
print('OK: base estruturalmente válida.')
PY
