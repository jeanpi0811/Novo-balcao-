#!/bin/bash
set -e
cd "$(dirname "$0")"
echo "Digite o contato público de suporte que aparecerá no app."
echo "Exemplos: email@dominio.com | WhatsApp (54) 99999-9999 | Instagram @perfil"
read -r CONTATO
if [ -z "$CONTATO" ]; then
  echo "Contato vazio. Nada alterado."
  exit 1
fi
python3 - "$CONTATO" <<'PY'
from pathlib import Path
import re
import sys
contato = sys.argv[1]
p = Path('src/data/appInfo.ts')
s = p.read_text()
s = re.sub(r"contatoSuporte: '[^']*'", "contatoSuporte: " + repr(contato), s)
p.write_text(s)
print('Contato atualizado:', contato)
PY
