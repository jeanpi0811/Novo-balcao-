#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "Limpando build iOS local..."
rm -rf ios
rm -rf ~/Library/Developer/Xcode/DerivedData/*Balcao* 2>/dev/null || true
rm -rf ~/Library/Developer/Xcode/DerivedData/*balcao* 2>/dev/null || true
echo "OK. Para gerar de novo, rode:"
echo "./01_GERAR_IOS_ABRIR_XCODE.command"
