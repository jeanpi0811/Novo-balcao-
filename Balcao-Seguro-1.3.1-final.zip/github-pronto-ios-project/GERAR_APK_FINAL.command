#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

./GERAR_APK_FINAL_REORGANIZADO.command
