#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "== Iniciando Balcão Seguro no Expo =="
npx expo start
