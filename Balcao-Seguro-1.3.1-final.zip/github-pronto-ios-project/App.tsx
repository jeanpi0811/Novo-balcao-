import React, { useEffect, useState } from 'react';
import { Alert, BackHandler, Share, StatusBar } from 'react-native';
import { theme } from './src/styles/theme';
import { HomeScreen } from './src/screens/HomeScreen';
import { AtendimentoScreen } from './src/screens/AtendimentoScreen';
import { TriagemScreen } from './src/screens/TriagemScreen';
import { MedicamentosScreen } from './src/screens/MedicamentosScreen';
import { InteracoesScreen } from './src/screens/InteracoesScreen';
import { TrocaSeguraScreen } from './src/screens/TrocaSeguraScreen';
import { RegistroScreen } from './src/screens/RegistroScreen';
import { MaisScreen } from './src/screens/MaisScreen';
import { InfoScreen } from './src/screens/InfoScreen';
import { PremiumScreen } from './src/screens/PremiumScreen';
import { DevScreen } from './src/screens/DevScreen';
import { carregarRegistros, limparRegistros, salvarRegistros } from './src/storage/registros';
import { RegistroAtendimento } from './src/types';
import { ScreenName } from './src/navigation';
import { AceiteInicialScreen } from './src/screens/AceiteInicialScreen';
import { AceiteTermos, carregarAceiteTermos, salvarAceiteTermos } from './src/storage/termos';
import { ativarPremiumDev, ativarPremiumPorCodigo, carregarPremium, desativarPremiumLocal, PremiumState, registrarConsultaCompleta, statusPremium, zerarConsultasGratis } from './src/storage/premium';
import { appInfo } from './src/data/appInfo';

// Consulta e seleção devem funcionar no plano grátis. O consumo Premium ocorre
// somente ao abrir o conteúdo completo/resultado, dentro de cada tela.
const TELAS_PRO: ScreenName[] = ['atendimento', 'triagem', 'registro'];

export default function App() {
  const [screen, setScreen] = useState<ScreenName>('home');
  const [historico, setHistorico] = useState<ScreenName[]>([]);
  const [registros, setRegistros] = useState<RegistroAtendimento[]>([]);
  const [carregado, setCarregado] = useState(false);
  const [aceiteTermos, setAceiteTermos] = useState<AceiteTermos | null>(null);
  const [aceiteCarregado, setAceiteCarregado] = useState(false);
  const [premium, setPremium] = useState<PremiumState>({ ativo: false, consultasUsadas: 0 });

  function navegarPara(destino: ScreenName) {
    if (destino === screen) return;
    setHistorico((atual) => [...atual, screen]);
    setScreen(destino);
  }

  function voltar() {
    setHistorico((atual) => {
      if (atual.length === 0) {
        setScreen('home');
        return atual;
      }
      const anterior = atual[atual.length - 1];
      setScreen(anterior);
      return atual.slice(0, -1);
    });
  }

  useEffect(() => {
    const assinatura = BackHandler.addEventListener('hardwareBackPress', () => {
      if (historico.length === 0) return false;
      voltar();
      return true;
    });
    return () => assinatura.remove();
  }, [historico]);

  useEffect(() => {
    carregarRegistros().then((dados) => {
      setRegistros(dados);
      setCarregado(true);
    });

    carregarAceiteTermos().then((aceite) => {
      setAceiteTermos(aceite);
      setAceiteCarregado(true);
    });

    carregarPremium().then(setPremium);
  }, []);

  async function adicionarRegistro(registro: RegistroAtendimento) {
    const novos = [registro, ...registros];
    setRegistros(novos);
    await salvarRegistros(novos);
    navegarPara('registro');
  }

  async function removerRegistros() {
    setRegistros([]);
    await limparRegistros();
  }

  async function aceitarTermos() {
    const aceite = await salvarAceiteTermos();
    setAceiteTermos(aceite);
    navegarPara('home');
  }

  async function usarConsultaCompleta() {
    const resultado = await registrarConsultaCompleta(premium);
    setPremium(resultado.estado);
    return resultado.permitido;
  }

  async function ativarCodigoPremium(codigo: string) {
    const resultado = await ativarPremiumPorCodigo(codigo, premium);
    setPremium(resultado.estado);
    return resultado;
  }

  async function ativarPremiumModoDev() {
    const novo = await ativarPremiumDev(premium);
    setPremium(novo);
  }

  async function desativarPremiumModoLocal() {
    const novo = await desativarPremiumLocal(premium);
    setPremium(novo);
  }

  async function zerarConsultasGratisLocal() {
    const novo = await zerarConsultasGratis(premium);
    setPremium(novo);
  }

  async function exportarDadosLocais() {
    const payload = {
      aplicativo: appInfo.nome,
      versao: appInfo.versao,
      tipo: 'exportacao-local-json',
      exportadoEm: new Date().toISOString(),
      responsavel: `${appInfo.responsavelFarmaceutico} — ${appInfo.registroProfissional}`,
      totalRegistros: registros.length,
      registros,
    };

    try {
      await Share.share({
        title: 'balcao-seguro-dados-locais.json',
        message: JSON.stringify(payload, null, 2),
      });
    } catch {
      Alert.alert('Exportação indisponível', 'Não foi possível abrir o compartilhamento de dados neste dispositivo.');
    }
  }

  const premiumStatus = statusPremium(premium);
  const bloqueadoPorPro = TELAS_PRO.includes(screen) && !premiumStatus.ativo;
  const onBack = historico.length > 0 ? voltar : undefined;

  if (!aceiteCarregado) {
    return <StatusBar barStyle="light-content" backgroundColor={theme.colors.bg} />;
  }

  if (!aceiteTermos) {
    return (
      <>
        <StatusBar barStyle="light-content" backgroundColor={theme.colors.bg} />
        <AceiteInicialScreen onAceitar={aceitarTermos} />
      </>
    );
  }

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor={theme.colors.bg} />
      {bloqueadoPorPro && <PremiumScreen onNavigate={navegarPara} activeScreen={screen} premiumStatus={premiumStatus} onAtivarCodigo={ativarCodigoPremium} recursoBloqueado={screen} />}
      {!bloqueadoPorPro && screen === 'home' && <HomeScreen onNavigate={navegarPara} totalRegistros={registros.length} activeScreen={screen} />}
      {!bloqueadoPorPro && screen === 'atendimento' && <AtendimentoScreen onNavigate={navegarPara} totalRegistros={registros.length} activeScreen={screen} />}
      {!bloqueadoPorPro && screen === 'triagem' && <TriagemScreen onNavigate={navegarPara} onSalvarRegistro={adicionarRegistro} activeScreen={screen} />}
      {!bloqueadoPorPro && screen === 'medicamentos' && <MedicamentosScreen onNavigate={navegarPara} onBack={onBack} activeScreen={screen} premiumStatus={premiumStatus} />}
      {!bloqueadoPorPro && screen === 'interacoes' && <InteracoesScreen onNavigate={navegarPara} onBack={onBack} activeScreen={screen} premiumStatus={premiumStatus} onUsarConsultaCompleta={usarConsultaCompleta} />}
      {!bloqueadoPorPro && screen === 'troca' && <TrocaSeguraScreen onNavigate={navegarPara} activeScreen={screen} />}
      {!bloqueadoPorPro && screen === 'registro' && <RegistroScreen onNavigate={navegarPara} registros={registros} onLimpar={removerRegistros} carregado={carregado} activeScreen={screen} />}
      {!bloqueadoPorPro && screen === 'mais' && <MaisScreen onNavigate={navegarPara} totalRegistros={registros.length} activeScreen={screen} onExportarDados={exportarDadosLocais} onLimparDados={removerRegistros} premiumStatus={premiumStatus} />}
      {!bloqueadoPorPro && screen === 'sobre' && <InfoScreen tipo="sobre" onNavigate={navegarPara} activeScreen={screen} />}
      {!bloqueadoPorPro && screen === 'termos' && <InfoScreen tipo="termos" onNavigate={navegarPara} activeScreen={screen} />}
      {!bloqueadoPorPro && screen === 'privacidade' && <InfoScreen tipo="privacidade" onNavigate={navegarPara} activeScreen={screen} />}
      {!bloqueadoPorPro && screen === 'fontes' && <InfoScreen tipo="fontes" onNavigate={navegarPara} activeScreen={screen} />}
      {!bloqueadoPorPro && screen === 'premium' && <PremiumScreen onNavigate={navegarPara} activeScreen={screen} premiumStatus={premiumStatus} onAtivarCodigo={ativarCodigoPremium} />}
      {!bloqueadoPorPro && screen === 'dev' && <DevScreen onNavigate={navegarPara} activeScreen={screen} premium={premium} premiumStatus={premiumStatus} totalRegistros={registros.length} onAtivarDev={ativarPremiumModoDev} onDesativarPremium={desativarPremiumModoLocal} onZerarConsultas={zerarConsultasGratisLocal} onExportarDados={exportarDadosLocais} onLimparDados={removerRegistros} />}
    </>
  );
}
