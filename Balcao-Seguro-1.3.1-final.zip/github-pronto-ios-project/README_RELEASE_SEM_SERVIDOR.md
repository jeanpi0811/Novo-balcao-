# Balcão Seguro — release sem servidor

## O que foi corrigido

O APK **debug** de React Native/Expo pode abrir pedindo Metro, servidor local ou dev server. Isso é normal em debug e não serve para distribuição.

Este projeto foi ajustado para gerar **APK release**, com o JavaScript do app embutido dentro do próprio APK. Assim, depois de instalado no Android, ele não precisa de servidor, Expo Go, Metro, computador ligado nem EAS Build.

## Workflow correto no GitHub

Use um destes workflows:

1. **Gerar APK Release Sem Servidor**  
   Gera APK direto para instalar no celular.

2. **Gerar Release Android - Balcao Seguro**  
   Gera APK direto e também AAB para Play Store.

Evite usar/gerar APK debug para testar distribuição final.

## Artefatos gerados

No final do GitHub Actions, baixe em **Artifacts**:

- `Balcao-Seguro-APK-Release-Sem-Servidor`
- opcionalmente `Balcao-Seguro-AAB-Play-Store`

## Assinatura

Se os GitHub Secrets de assinatura não forem configurados, o workflow cria uma chave temporária. Isso permite instalar o APK direto, mas pode exigir desinstalar o app antes de instalar uma próxima versão.

Para atualização por cima sem erro de assinatura, configure uma chave fixa nos Secrets:

```txt
ANDROID_KEYSTORE_BASE64
ANDROID_KEYSTORE_PASSWORD
ANDROID_KEY_ALIAS
ANDROID_KEY_PASSWORD
```

## Versão

Esta correção atualizou:

```txt
versionName: 1.1.6
versionCode: 6
package: br.com.farmabolso.balcaoseguro
```

## Conferência automática

O workflow roda:

```bash
python3 scripts/validar_apk_sem_servidor.py android/app/build/outputs/apk/release/app-release.apk
```

Ele falha se não encontrar o bundle JS dentro do APK, porque isso indicaria risco de depender de Metro/dev server.
