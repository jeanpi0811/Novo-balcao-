# Balcão Seguro — reconstrução 1.3.1

## Alterações concluídas

A base foi atualizada para Expo 57, React Native 0.86.3 e `babel-preset-expo` 57. O diagnóstico final passou em 21 de 21 verificações e o TypeScript foi aprovado.

O ícone fornecido pelo cliente foi aplicado como identidade do aplicativo. O preto externo foi removido por transparência, preservando o balcão azul, o escudo, os medicamentos e a tipografia da arte original. O asset final está em `assets/home-icon-transparent.png` e também foi usado nos assets principais do app.

A Home agora exibe esse ícone acima dos módulos principais. A entrada usa uma animação breve de opacidade e deslocamento vertical, com `useNativeDriver`, para manter a interação discreta e performática.

## Validação

- TypeScript: aprovado com `npm run typecheck`.
- Expo Doctor: 21/21 verificações aprovadas.
- Android release: não foi possível gerar um APK novo neste ambiente porque não há Android SDK configurado (`ANDROID_HOME` vazio e `sdk.dir` ausente). O Gradle foi localizado, mas o build parou antes da compilação por `SDK location not found`.
- iOS: o projeto está preparado para abrir e compilar no macOS/Xcode, mas a assinatura/IPA requer certificados Apple e macOS.

## Como gerar o APK

No ambiente Android com SDK instalado, executar:

```bash
npm ci
npm run typecheck
npx expo-doctor
npm run apk:release
```

O arquivo será gerado em `android/app/build/outputs/apk/release/app-release.apk`.
