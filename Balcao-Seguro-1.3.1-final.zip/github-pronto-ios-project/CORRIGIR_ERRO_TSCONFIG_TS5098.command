#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "== Balcão Seguro: corrigir tsconfig TS5098 / TS5101 / TS5107 =="
cat > tsconfig.json <<'JSON'
{
  "extends": "expo/tsconfig.base",
  "compilerOptions": {
    "strict": true,
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "jsx": "react-jsx",
    "target": "ES2020",
    "lib": [
      "DOM",
      "ES2020"
    ],
    "allowSyntheticDefaultImports": true,
    "noEmit": true,
    "ignoreDeprecations": "6.0"
  },
  "include": [
    "App.tsx",
    "src/**/*.ts",
    "src/**/*.tsx"
  ],
  "exclude": [
    "node_modules",
    "android",
    "ios",
    "build",
    "dist"
  ]
}
JSON

echo "tsconfig.json corrigido. Rodando TypeScript agora..."
npm run typecheck

echo "OK. Agora rode: ./10_GERAR_APK_AAB_COM_LOG.command"
