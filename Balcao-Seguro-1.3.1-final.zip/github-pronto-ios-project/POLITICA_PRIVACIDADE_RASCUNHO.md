# Política de Privacidade — Balcão Seguro

Versão: 1.0.0
Responsável pelo conteúdo farmacêutico inicial: Jean Pierre Andres — CRF/RS 15974
Contato de suporte: WhatsApp (54) 99142-7519

O Balcão Seguro foi preparado para funcionar localmente no aparelho. A versão atual não exige login e não envia automaticamente registros de atendimento para servidores externos.

Os registros criados no app ficam salvos no armazenamento local do dispositivo. O usuário pode compartilhar manualmente um registro usando os recursos do próprio sistema operacional; nesse caso, o destino escolhido passa a ser responsabilidade do usuário.

O app não solicita permissões sensíveis nesta configuração inicial. Mesmo assim, recomenda-se evitar inserir dados pessoais desnecessários nos registros.

O app não substitui avaliação médica, farmacêutica, bula, protocolos institucionais ou legislação sanitária aplicável.

Antes de publicação comercial ou uso amplo, revise este texto juridicamente e confirme se haverá coleta, analytics, crash logs, anúncios, servidor, backup em nuvem ou integração externa. Se algum desses itens for adicionado, esta política precisa ser atualizada.
