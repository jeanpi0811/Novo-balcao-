#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

echo "============================================"
echo " Balcão Seguro — validar pré-build"
echo "============================================"

npm config set registry https://registry.npmjs.org/

if [ ! -d node_modules ]; then
  echo "node_modules não encontrado. Preparando dependências..."
  ./01_PREPARAR_DEPENDENCIAS.command
fi

npx tsc --noEmit
python3 scripts/validar_base_medicamentos.py || true
python3 scripts/validar_base_enriquecida.py
npx expo-doctor || true

echo "OK. Ambiente conferido para tentar gerar o APK."
