#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

echo "============================================"
echo " Balcão Seguro — gerar APK final direto"
echo "============================================"
echo "Esta versão foi ajustada para gerar APK instalável, não AAB."
echo ""

./02_GERAR_APK_DIRETO_ASSINADO.command

echo ""
echo "Pronto. Arquivo final esperado:"
echo "- Balcao-Seguro-v1.0.0-final.apk"
echo ""
echo "Instalação no Android via cabo:"
echo "adb install -r Balcao-Seguro-v1.0.0-final.apk"
