# Balcão Seguro — Base oficial validável

Cada medicamento agora pode carregar rastreabilidade, fonte e status de validação.

## Status de validação
- `pendente`: item sem fonte suficiente. Não usar como orientação final.
- `parcial`: registro/fonte rastreável, mas informação clínica ainda precisa de bula profissional.
- `validado`: produto, registro, bula profissional, alertas, contraindicações e curadoria foram conferidos.
- `desatualizado`: item passou da data de revisão ou precisa de nova conferência.

## Importar base oficial da Anvisa
```bash
chmod +x *.command scripts/*.py
./06_BAIXAR_BASE_OFICIAL_ANVISA.command
./07_IMPORTAR_BASE_OFICIAL_ANVISA.command
./08_VALIDAR_BASE_MEDICAMENTOS.command
```

Por padrão, o importador traz até 500 registros válidos e marca como `parcial`, porque registro sanitário não é o mesmo que validação clínica da bula.

## Promover para `validado`
1. Abrir o produto no Sistema de Consultas/Bulário da Anvisa.
2. Conferir número de registro, detentor, princípio ativo, concentração e apresentação.
3. Conferir bula do paciente e bula profissional.
4. Preencher alertas e contraindicações em linguagem segura.
5. Inserir fonte `BULA_PROFISSIONAL` ou `ANVISA_BULARIO` com data de acesso.
6. Atualizar `revisadoEm`, `revisadoPor` e `statusValidacao: "validado"`.
7. Rodar `./08_VALIDAR_BASE_MEDICAMENTOS.command`.
8. Compilar APK/AAB.
