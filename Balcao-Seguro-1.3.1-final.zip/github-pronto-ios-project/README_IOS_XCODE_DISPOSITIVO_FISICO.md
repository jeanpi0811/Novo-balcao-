# Balcão Seguro v1.2.2 — instalação no iPhone físico via macOS + Xcode

Este pacote é para gerar a pasta `ios/` localmente no Mac e abrir o projeto no Xcode para instalar no iPhone físico.

## Compatibilidade preparada

- Projeto: Expo/React Native.
- Bundle iOS: `br.com.farmabolso.balcaoseguro`
- Versão: `1.2.2`
- iOS deployment target recomendado/forçado nos arquivos gerados: `16.4`
- Base local mantida: 5.200 itens
- Premium local/limite de 3 consultas mantido

## Atenção para iOS 27 beta

Se o iPhone estiver em iOS beta muito novo e o Xcode estável não reconhecer o aparelho, instale o Xcode beta compatível com essa versão do iOS.

## Passo a passo

### 1. Extraia o ZIP

Extraia o projeto em uma pasta simples, por exemplo:

`~/Desktop/balcao-seguro-ios`

Evite caminho com acentos ou caracteres estranhos.

### 2. Rode o preparo

Clique duas vezes ou rode pelo Terminal:

```bash
./00_PREPARAR_MAC_IOS_XCODE.command
```

Esse script confere Xcode, Node.js, CocoaPods e instala as dependências do projeto.

### 3. Gere o projeto iOS e abra no Xcode

```bash
./01_GERAR_IOS_ABRIR_XCODE.command
```

Ele faz:

- `expo prebuild -p ios`
- ajusta deployment target para iOS 16.4
- roda `pod install`
- abre o Xcode

### 4. No Xcode

1. Conecte o iPhone por cabo.
2. Toque em **Confiar** no iPhone.
3. Ative **Modo Desenvolvedor** se o iOS pedir.
4. No Xcode, abra o projeto/target do app.
5. Vá em **Signing & Capabilities**.
6. Marque **Automatically manage signing**.
7. Em **Team**, selecione seu Apple ID ou conta Apple Developer.
8. Se der erro no Bundle Identifier, altere para algo único, por exemplo:

`br.com.farmabolso.balcaoseguro.jean`

9. Selecione seu iPhone no topo.
10. Clique em **Run ▶**.

## Conta Apple

Com Apple ID gratuito, costuma servir para teste local no seu aparelho. Para TestFlight/App Store/distribuir para terceiros, precisa Apple Developer Program.

## Scripts inclusos

- `00_PREPARAR_MAC_IOS_XCODE.command` — prepara o Mac
- `01_GERAR_IOS_ABRIR_XCODE.command` — gera ios/ e abre Xcode
- `02_ABRIR_XCODE.command` — reabre Xcode depois
- `03_LIMPAR_IOS_XCODE.command` — apaga ios/ e DerivedData do app
- `04_DIAGNOSTICO_IOS_XCODE.command` — gera diagnóstico do ambiente

## Se falhar

Rode:

```bash
./04_DIAGNOSTICO_IOS_XCODE.command
```

e envie o print/log do erro.
